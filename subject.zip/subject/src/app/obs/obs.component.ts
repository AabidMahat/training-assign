import { Component, OnInit, OnDestroy } from '@angular/core';
import { interval, map, Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-obs',
  standalone: false,
  templateUrl: './obs.component.html',
  styleUrls: ['./obs.component.scss'],
})
export class ObsComponent implements OnInit, OnDestroy {
  stockSubject = new Subject<number>();
  subscriber: { subscription: Subscription; latestPrice: Subject<number> }[] =
    [];

  ngOnInit(): void {
    interval(2000)
      .pipe(map(() => Math.round(Math.random() * 10000)))
      .subscribe({
        next: (data) => this.stockSubject.next(data),
      });
  }

  addSubscriber(): void {
    const latestPrice = new Subject<number>();
    const subscription = this.stockSubject.subscribe({
      next: (price) => latestPrice.next(price),
    });

    this.subscriber.push({ subscription, latestPrice });
  }

  removeSubscriber(): void {
    if (this.subscriber.length > 0) {
      const removed = this.subscriber.pop();
      removed?.subscription.unsubscribe();
    }
  }

  ngOnDestroy(): void {
    this.subscriber.forEach((sub) => sub.subscription.unsubscribe());
  }
}

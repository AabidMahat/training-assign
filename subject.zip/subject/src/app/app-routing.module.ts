import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ObsComponent } from './obs/obs.component';

const routes: Routes = [
  {
    path: '',
    component: ObsComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}

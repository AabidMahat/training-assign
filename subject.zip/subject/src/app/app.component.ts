import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { debounceTime, fromEvent, map, throttleTime } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  @ViewChild('myContent', { static: true }) myInput!: ElementRef;
  @ViewChild('myButton', { static: true }) myButton!: ElementRef;
  ngOnInit(): void {
    fromEvent(this.myInput.nativeElement, 'input')
      .pipe(
        debounceTime(5000),
        map((event: any) => event.target.value)
      )
      .subscribe({
        next: (data) => console.log(data),
      });

    fromEvent(this.myButton.nativeElement, 'click')
      .pipe(throttleTime(2000))
      .subscribe({
        next: () => console.log('Clicked'),
      });
  }
}

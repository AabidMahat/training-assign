import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'project1';
  childMessage!: string;

  onRecieveMsg(messgae: string): void {
    this.childMessage = messgae;
  }
}

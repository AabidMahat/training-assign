import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrderModule } from './order/order.module';
import { LoginComponent } from './user/component/login/login.component';
import { UserModule } from './user/user.module';
import { ProfileComponent } from './profile/profile.component';

@NgModule({
  declarations: [AppComponent, ProfileComponent],
  imports: [BrowserModule, AppRoutingModule, OrderModule, UserModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}

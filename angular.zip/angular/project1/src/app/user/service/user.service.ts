import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
  readUserData(): void {
    console.log('This is local User Service');
  }
}

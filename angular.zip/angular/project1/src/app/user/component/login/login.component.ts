import { Component } from '@angular/core';
import { UserService } from '../../service/user.service';
import { Service } from '../../../order/order.service';

@Component({
  selector: 'app-login',
  standalone: false,

  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  providers: [UserService],
})
export class LoginComponent {
  constructor(
    private userService: UserService,
    private orderService: Service
  ) {}

  getData(): void {
    this.userService.readUserData();
  }

  globalService(): void {
    this.orderService.readData();
  }
}

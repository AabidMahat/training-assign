import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-order',
  standalone: false,

  templateUrl: './order.component.html',
  styleUrl: './order.component.css',
})
export class OrderComponent {
  @Input({ required: true }) parentMessage!: string;

  @Output() sendMessage = new EventEmitter<string>();

  onSendMsg(message: string): void {
    this.sendMessage.emit(message);
  }
}

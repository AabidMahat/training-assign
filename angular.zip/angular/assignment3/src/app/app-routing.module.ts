import { NgModule } from '@angular/core';
import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { TaskListComponent } from './task/task-list/task-list.component';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { TaskCreateComponent } from './task/task-create/task-create.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
  },

  {
    path: 'task/:taskId',
    component: TaskListComponent,
    children: [
      {
        path: 'create',
        component: TaskCreateComponent,
      },
    ],
  },
  {
    path: '**',
    component: NotFoundComponent,
  },
];

const routeOption: ExtraOptions = {
  paramsInheritanceStrategy: 'always',
  bindToComponentInputs: true,
};

@NgModule({
  imports: [RouterModule.forRoot(routes, routeOption)],
  exports: [RouterModule],
})
export class AppRoutingModule {}

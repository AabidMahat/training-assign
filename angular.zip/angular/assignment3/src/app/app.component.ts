import { Component } from '@angular/core';
import { Task } from './task/task.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'assignment3';
  newTask!: Task;

  onGetNewTask(task: Task): void {
    this.newTask = task;
  }
}

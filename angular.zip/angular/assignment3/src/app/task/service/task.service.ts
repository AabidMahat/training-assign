import { Injectable } from '@angular/core';
import { Status, Task } from '../task.model';

@Injectable()
export class TaskService {
  tasks: Task[] = [
    { id: 1, name: 'Task 1', status: Status.Pending, priority: 'High' },
    { id: 2, name: 'Task 2', status: Status.Progress, priority: 'Medium' },
    { id: 3, name: 'Task 3', status: Status.Completed, priority: 'Low' },
    { id: 4, name: 'Task 4', status: Status.Pending, priority: 'High' },
    { id: 5, name: 'Task 5', status: Status.Progress, priority: 'Low' },
    { id: 6, name: 'Task 6', status: Status.Completed, priority: 'Medium' },
    { id: 7, name: 'Task 7', status: Status.Pending, priority: 'Low' },
    { id: 8, name: 'Task 8', status: Status.Progress, priority: 'High' },
    { id: 9, name: 'Task 9', status: Status.Completed, priority: 'Medium' },
    { id: 10, name: 'Task 10', status: Status.Pending, priority: 'High' },
  ];

  createTask(task: Task): void {
    this.tasks.push(task);
    console.log('Action Triggered');
  }

  getAllTask(): Task[] {
    return this.tasks;
  }

  updateStatus(taskId: number, newStatus: Status): void {
    const task: Task = this.tasks.find((task) => task.id === taskId)!;
    task.status = newStatus;

    console.log(task);

    this.getAllTask();
  }

  deleteTask(taskId: number): void {
    const isTaskAvaliable = this.tasks.some((task) => task.id === taskId);

    if (isTaskAvaliable) {
      const taskIndex = this.tasks.findIndex((task) => task.id === taskId);
      this.tasks.splice(taskIndex, 1);
      this.getAllTask();
    }
  }
}

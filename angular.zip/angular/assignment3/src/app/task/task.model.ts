export enum Status {
  Pending = 'pending',
  Progress = 'progress',
  Completed = 'completed',
}

export interface Task {
  id: number;
  name: string;
  status: Status;
  priority: 'High' | 'Medium' | 'Low';
}

import {
  Component,
  DestroyRef,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { Status, Task } from '../task.model';
import { TaskService } from '../service/task.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-task-list',
  standalone: false,
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css',
  providers: [TaskService],
})
export class TaskListComponent implements OnInit, OnChanges {
  constructor(
    private taskService: TaskService,
    private activatedRoute: ActivatedRoute
  ) {}

  @Input({ required: true }) taskId!: number;
  myTaskId!: number;

  @Input() newTask!: Task;

  allTask: Task[] = [];

  ngOnInit(): void {
    this.allTask = this.taskService.getAllTask();

    // this.activatedRoute.paramMap.subscribe({
    //   next: (res) => (this.myTaskId = +res.get('taskId')!),
    // });
    this.myTaskId = +this.activatedRoute.snapshot.paramMap.get('taskId')!;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['newTask'] && changes['newTask'].currentValue) {
      this.addTask();
    }
  }

  addTask() {
    this.taskService.createTask(this.newTask);
  }

  updateStatus(taskId: number, status: string): void {
    this.taskService.updateStatus(taskId, status as Status);
  }

  deleteTask(taskId: number) {
    this.taskService.deleteTask(taskId);
  }
}

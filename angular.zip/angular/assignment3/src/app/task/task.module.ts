import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { TaskListComponent } from './task-list/task-list.component';
import { TaskCreateComponent } from './task-create/task-create.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [TaskListComponent, TaskCreateComponent],
  imports: [CommonModule, SharedModule, DatePipe, DecimalPipe],
  providers: [],
  exports: [TaskListComponent, TaskCreateComponent],
})
export class TaskModule {}

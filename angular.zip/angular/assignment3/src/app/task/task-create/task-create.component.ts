import { Component, EventEmitter, Output } from '@angular/core';
import { Status, Task } from '../task.model';

@Component({
  selector: 'app-task-create',
  standalone: false,

  templateUrl: './task-create.component.html',
  styleUrl: './task-create.component.css',
})
export class TaskCreateComponent {
  @Output() select = new EventEmitter();

  newTask: Task = {
    id: 11,
    name: 'Task11',
    priority: 'High',
    status: Status.Progress,
  };

  onAddTask() {
    this.select.emit(this.newTask);
  }
}

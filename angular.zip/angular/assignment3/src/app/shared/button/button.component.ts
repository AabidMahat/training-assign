import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  standalone: false,

  templateUrl: './button.component.html',
  styleUrl: './button.component.css',
})
export class ButtonComponent {
  @Input() btnName!: string;
  @Input() btnAction!: number;
  @Input() type: 'standard' | 'white' | 'delete' = 'standard';

  @Output() onButtonClick = new EventEmitter<boolean>();
}

import { Component, OnInit } from '@angular/core';
import { of } from 'rxjs';
import { UserService } from './user/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit {
  constructor(private userService: UserService) {}
  activated: boolean = false;

  ngOnInit(): void {
    this.userService.userActivated.subscribe(
      (didActivated) => (this.activated = didActivated)
    );
  }
}

import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { Observable } from 'rxjs-compat';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent implements OnInit {
  subscription!: Subscription;
  status: string[] = [];
  ngOnInit(): void {
    const observable = new Observable<string>((obs) => {
      setTimeout(() => {
        obs.next('Order Placed');
      }, 1000);
      setTimeout(() => {
        obs.next('Order Shipped');
      }, 3000);
      setTimeout(() => {
        obs.next('Order Completed');
      }, 5000);
      setTimeout(() => {
        obs.complete();
      }, 7000);
    });

    this.subscription = observable.subscribe({
      next: (data) => this.status.push(data),
    });
  }

  destory(): void {
    this.subscription.unsubscribe();
    console.log('Unsuscribed');
  }
}

import {
  SubscribeOnObservable,
  TimeInterval,
  Timestamp,
  defaultThrottleConfig,
  init_SubscribeOnObservable,
  init_isDate,
  init_operators,
  init_throttle,
  init_timeInterval,
  init_timestamp,
  isDate,
  operators_exports
} from "./chunk-QQYHD5XP.js";
import {
  AnonymousSubject,
  ArgumentOutOfRangeError,
  AsyncScheduler,
  CombineLatestOperator,
  EmptyError,
  GroupedObservable,
  Immediate,
  InnerSubscriber,
  Notification,
  ObjectUnsubscribedError,
  Observable,
  OuterSubscriber,
  ReplaySubject,
  Scheduler,
  Subject,
  SubjectSubscription,
  Subscriber,
  Subscription,
  TimeoutError,
  UnsubscriptionError,
  VirtualAction,
  VirtualTimeScheduler,
  __assign,
  __commonJS,
  __esm,
  __export,
  __extends,
  __toCommonJS,
  config,
  dispatch,
  esm5_exports,
  hostReportError,
  identity,
  init_ArgumentOutOfRangeError,
  init_AsyncScheduler,
  init_EmptyError,
  init_Immediate,
  init_InnerSubscriber,
  init_Notification,
  init_ObjectUnsubscribedError,
  init_Observable,
  init_OuterSubscriber,
  init_ReplaySubject,
  init_Scheduler,
  init_Subject,
  init_SubjectSubscription,
  init_Subscriber,
  init_Subscription,
  init_TimeoutError,
  init_UnsubscriptionError,
  init_VirtualTimeScheduler,
  init_combineLatest,
  init_config,
  init_esm5,
  init_groupBy,
  init_hostReportError,
  init_identity,
  init_isArray,
  init_isArrayLike,
  init_isFunction,
  init_isInteropObservable,
  init_isIterable,
  init_isNumeric,
  init_isObject,
  init_isPromise,
  init_isScheduler,
  init_iterator,
  init_map,
  init_noop,
  init_not,
  init_observable,
  init_pipe,
  init_range,
  init_rxSubscriber,
  init_scheduleIterable,
  init_schedulePromise,
  init_subscribeTo,
  init_subscribeToArray,
  init_subscribeToIterable,
  init_subscribeToObservable,
  init_subscribeToPromise,
  init_subscribeToResult,
  init_toSubscriber,
  init_tslib_es6,
  isArray,
  isArrayLike,
  isFunction,
  isInteropObservable,
  isIterable,
  isNumeric,
  isObject,
  isPromise,
  isScheduler,
  iterator,
  map,
  noop,
  not,
  observable,
  pipe,
  rxSubscriber,
  scheduleIterable,
  schedulePromise,
  subscribeTo,
  subscribeToArray,
  subscribeToIterable,
  subscribeToObservable,
  subscribeToPromise,
  subscribeToResult,
  toSubscriber
} from "./chunk-C3SEPGQU.js";

// node_modules/rxjs/_esm5/internal/observable/fromPromise.js
function fromPromise(input, scheduler) {
  if (!scheduler) {
    return new Observable(subscribeToPromise(input));
  } else {
    return schedulePromise(input, scheduler);
  }
}
var init_fromPromise = __esm({
  "node_modules/rxjs/_esm5/internal/observable/fromPromise.js"() {
    init_Observable();
    init_subscribeToPromise();
    init_schedulePromise();
  }
});

// node_modules/rxjs/_esm5/internal/observable/fromIterable.js
function fromIterable(input, scheduler) {
  if (!input) {
    throw new Error("Iterable cannot be null");
  }
  if (!scheduler) {
    return new Observable(subscribeToIterable(input));
  } else {
    return scheduleIterable(input, scheduler);
  }
}
var init_fromIterable = __esm({
  "node_modules/rxjs/_esm5/internal/observable/fromIterable.js"() {
    init_Observable();
    init_subscribeToIterable();
    init_scheduleIterable();
  }
});

// node_modules/rxjs/_esm5/internal/util/root.js
var __window, __self, __global, _root;
var init_root = __esm({
  "node_modules/rxjs/_esm5/internal/util/root.js"() {
    __window = typeof window !== "undefined" && window;
    __self = typeof self !== "undefined" && typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope && self;
    __global = typeof global !== "undefined" && global;
    _root = __window || __global || __self;
    (function() {
      if (!_root) {
        throw new Error("RxJS could not find any global context (window, self, global)");
      }
    })();
  }
});

// node_modules/rxjs/_esm5/internal/observable/dom/AjaxObservable.js
function getCORSRequest() {
  if (_root.XMLHttpRequest) {
    return new _root.XMLHttpRequest();
  } else if (!!_root.XDomainRequest) {
    return new _root.XDomainRequest();
  } else {
    throw new Error("CORS is not supported by your browser");
  }
}
function getXMLHttpRequest() {
  if (_root.XMLHttpRequest) {
    return new _root.XMLHttpRequest();
  } else {
    var progId = void 0;
    try {
      var progIds = ["Msxml2.XMLHTTP", "Microsoft.XMLHTTP", "Msxml2.XMLHTTP.4.0"];
      for (var i = 0; i < 3; i++) {
        try {
          progId = progIds[i];
          if (new _root.ActiveXObject(progId)) {
            break;
          }
        } catch (e) {
        }
      }
      return new _root.ActiveXObject(progId);
    } catch (e) {
      throw new Error("XMLHttpRequest is not supported by your browser");
    }
  }
}
function ajaxGet(url, headers) {
  if (headers === void 0) {
    headers = null;
  }
  return new AjaxObservable({
    method: "GET",
    url,
    headers
  });
}
function ajaxPost(url, body, headers) {
  return new AjaxObservable({
    method: "POST",
    url,
    body,
    headers
  });
}
function ajaxDelete(url, headers) {
  return new AjaxObservable({
    method: "DELETE",
    url,
    headers
  });
}
function ajaxPut(url, body, headers) {
  return new AjaxObservable({
    method: "PUT",
    url,
    body,
    headers
  });
}
function ajaxPatch(url, body, headers) {
  return new AjaxObservable({
    method: "PATCH",
    url,
    body,
    headers
  });
}
function ajaxGetJSON(url, headers) {
  return mapResponse(new AjaxObservable({
    method: "GET",
    url,
    responseType: "json",
    headers
  }));
}
function parseJson(xhr) {
  if ("response" in xhr) {
    return xhr.responseType ? xhr.response : JSON.parse(xhr.response || xhr.responseText || "null");
  } else {
    return JSON.parse(xhr.responseText || "null");
  }
}
function parseXhrResponse(responseType, xhr) {
  switch (responseType) {
    case "json":
      return parseJson(xhr);
    case "xml":
      return xhr.responseXML;
    case "text":
    default:
      return "response" in xhr ? xhr.response : xhr.responseText;
  }
}
function AjaxTimeoutErrorImpl(xhr, request) {
  AjaxError.call(this, "ajax timeout", xhr, request);
  this.name = "AjaxTimeoutError";
  return this;
}
var mapResponse, AjaxObservable, AjaxSubscriber, AjaxResponse, AjaxErrorImpl, AjaxError, AjaxTimeoutError;
var init_AjaxObservable = __esm({
  "node_modules/rxjs/_esm5/internal/observable/dom/AjaxObservable.js"() {
    init_tslib_es6();
    init_root();
    init_Observable();
    init_Subscriber();
    init_map();
    mapResponse = map(function(x, index) {
      return x.response;
    });
    AjaxObservable = function(_super) {
      __extends(AjaxObservable2, _super);
      function AjaxObservable2(urlOrRequest) {
        var _this = _super.call(this) || this;
        var request = {
          async: true,
          createXHR: function() {
            return this.crossDomain ? getCORSRequest() : getXMLHttpRequest();
          },
          crossDomain: true,
          withCredentials: false,
          headers: {},
          method: "GET",
          responseType: "json",
          timeout: 0
        };
        if (typeof urlOrRequest === "string") {
          request.url = urlOrRequest;
        } else {
          for (var prop in urlOrRequest) {
            if (urlOrRequest.hasOwnProperty(prop)) {
              request[prop] = urlOrRequest[prop];
            }
          }
        }
        _this.request = request;
        return _this;
      }
      AjaxObservable2.prototype._subscribe = function(subscriber) {
        return new AjaxSubscriber(subscriber, this.request);
      };
      AjaxObservable2.create = function() {
        var create = function(urlOrRequest) {
          return new AjaxObservable2(urlOrRequest);
        };
        create.get = ajaxGet;
        create.post = ajaxPost;
        create.delete = ajaxDelete;
        create.put = ajaxPut;
        create.patch = ajaxPatch;
        create.getJSON = ajaxGetJSON;
        return create;
      }();
      return AjaxObservable2;
    }(Observable);
    AjaxSubscriber = function(_super) {
      __extends(AjaxSubscriber2, _super);
      function AjaxSubscriber2(destination, request) {
        var _this = _super.call(this, destination) || this;
        _this.request = request;
        _this.done = false;
        var headers = request.headers = request.headers || {};
        if (!request.crossDomain && !_this.getHeader(headers, "X-Requested-With")) {
          headers["X-Requested-With"] = "XMLHttpRequest";
        }
        var contentTypeHeader = _this.getHeader(headers, "Content-Type");
        if (!contentTypeHeader && !(_root.FormData && request.body instanceof _root.FormData) && typeof request.body !== "undefined") {
          headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8";
        }
        request.body = _this.serializeBody(request.body, _this.getHeader(request.headers, "Content-Type"));
        _this.send();
        return _this;
      }
      AjaxSubscriber2.prototype.next = function(e) {
        this.done = true;
        var _a = this, xhr = _a.xhr, request = _a.request, destination = _a.destination;
        var result;
        try {
          result = new AjaxResponse(e, xhr, request);
        } catch (err) {
          return destination.error(err);
        }
        destination.next(result);
      };
      AjaxSubscriber2.prototype.send = function() {
        var _a = this, request = _a.request, _b = _a.request, user = _b.user, method = _b.method, url = _b.url, async = _b.async, password = _b.password, headers = _b.headers, body = _b.body;
        try {
          var xhr = this.xhr = request.createXHR();
          this.setupEvents(xhr, request);
          if (user) {
            xhr.open(method, url, async, user, password);
          } else {
            xhr.open(method, url, async);
          }
          if (async) {
            xhr.timeout = request.timeout;
            xhr.responseType = request.responseType;
          }
          if ("withCredentials" in xhr) {
            xhr.withCredentials = !!request.withCredentials;
          }
          this.setHeaders(xhr, headers);
          if (body) {
            xhr.send(body);
          } else {
            xhr.send();
          }
        } catch (err) {
          this.error(err);
        }
      };
      AjaxSubscriber2.prototype.serializeBody = function(body, contentType) {
        if (!body || typeof body === "string") {
          return body;
        } else if (_root.FormData && body instanceof _root.FormData) {
          return body;
        }
        if (contentType) {
          var splitIndex = contentType.indexOf(";");
          if (splitIndex !== -1) {
            contentType = contentType.substring(0, splitIndex);
          }
        }
        switch (contentType) {
          case "application/x-www-form-urlencoded":
            return Object.keys(body).map(function(key) {
              return encodeURIComponent(key) + "=" + encodeURIComponent(body[key]);
            }).join("&");
          case "application/json":
            return JSON.stringify(body);
          default:
            return body;
        }
      };
      AjaxSubscriber2.prototype.setHeaders = function(xhr, headers) {
        for (var key in headers) {
          if (headers.hasOwnProperty(key)) {
            xhr.setRequestHeader(key, headers[key]);
          }
        }
      };
      AjaxSubscriber2.prototype.getHeader = function(headers, headerName) {
        for (var key in headers) {
          if (key.toLowerCase() === headerName.toLowerCase()) {
            return headers[key];
          }
        }
        return void 0;
      };
      AjaxSubscriber2.prototype.setupEvents = function(xhr, request) {
        var progressSubscriber = request.progressSubscriber;
        function xhrTimeout(e) {
          var _a = xhrTimeout, subscriber = _a.subscriber, progressSubscriber2 = _a.progressSubscriber, request2 = _a.request;
          if (progressSubscriber2) {
            progressSubscriber2.error(e);
          }
          var error;
          try {
            error = new AjaxTimeoutError(this, request2);
          } catch (err) {
            error = err;
          }
          subscriber.error(error);
        }
        xhr.ontimeout = xhrTimeout;
        xhrTimeout.request = request;
        xhrTimeout.subscriber = this;
        xhrTimeout.progressSubscriber = progressSubscriber;
        if (xhr.upload && "withCredentials" in xhr) {
          if (progressSubscriber) {
            var xhrProgress_1;
            xhrProgress_1 = function(e) {
              var progressSubscriber2 = xhrProgress_1.progressSubscriber;
              progressSubscriber2.next(e);
            };
            if (_root.XDomainRequest) {
              xhr.onprogress = xhrProgress_1;
            } else {
              xhr.upload.onprogress = xhrProgress_1;
            }
            xhrProgress_1.progressSubscriber = progressSubscriber;
          }
          var xhrError_1;
          xhrError_1 = function(e) {
            var _a = xhrError_1, progressSubscriber2 = _a.progressSubscriber, subscriber = _a.subscriber, request2 = _a.request;
            if (progressSubscriber2) {
              progressSubscriber2.error(e);
            }
            var error;
            try {
              error = new AjaxError("ajax error", this, request2);
            } catch (err) {
              error = err;
            }
            subscriber.error(error);
          };
          xhr.onerror = xhrError_1;
          xhrError_1.request = request;
          xhrError_1.subscriber = this;
          xhrError_1.progressSubscriber = progressSubscriber;
        }
        function xhrReadyStateChange(e) {
          return;
        }
        xhr.onreadystatechange = xhrReadyStateChange;
        xhrReadyStateChange.subscriber = this;
        xhrReadyStateChange.progressSubscriber = progressSubscriber;
        xhrReadyStateChange.request = request;
        function xhrLoad(e) {
          var _a = xhrLoad, subscriber = _a.subscriber, progressSubscriber2 = _a.progressSubscriber, request2 = _a.request;
          if (this.readyState === 4) {
            var status_1 = this.status === 1223 ? 204 : this.status;
            var response = this.responseType === "text" ? this.response || this.responseText : this.response;
            if (status_1 === 0) {
              status_1 = response ? 200 : 0;
            }
            if (status_1 < 400) {
              if (progressSubscriber2) {
                progressSubscriber2.complete();
              }
              subscriber.next(e);
              subscriber.complete();
            } else {
              if (progressSubscriber2) {
                progressSubscriber2.error(e);
              }
              var error = void 0;
              try {
                error = new AjaxError("ajax error " + status_1, this, request2);
              } catch (err) {
                error = err;
              }
              subscriber.error(error);
            }
          }
        }
        xhr.onload = xhrLoad;
        xhrLoad.subscriber = this;
        xhrLoad.progressSubscriber = progressSubscriber;
        xhrLoad.request = request;
      };
      AjaxSubscriber2.prototype.unsubscribe = function() {
        var _a = this, done = _a.done, xhr = _a.xhr;
        if (!done && xhr && xhr.readyState !== 4 && typeof xhr.abort === "function") {
          xhr.abort();
        }
        _super.prototype.unsubscribe.call(this);
      };
      return AjaxSubscriber2;
    }(Subscriber);
    AjaxResponse = /* @__PURE__ */ function() {
      function AjaxResponse2(originalEvent, xhr, request) {
        this.originalEvent = originalEvent;
        this.xhr = xhr;
        this.request = request;
        this.status = xhr.status;
        this.responseType = xhr.responseType || request.responseType;
        this.response = parseXhrResponse(this.responseType, xhr);
      }
      return AjaxResponse2;
    }();
    AjaxErrorImpl = function() {
      function AjaxErrorImpl2(message, xhr, request) {
        Error.call(this);
        this.message = message;
        this.name = "AjaxError";
        this.xhr = xhr;
        this.request = request;
        this.status = xhr.status;
        this.responseType = xhr.responseType || request.responseType;
        this.response = parseXhrResponse(this.responseType, xhr);
        return this;
      }
      AjaxErrorImpl2.prototype = Object.create(Error.prototype);
      return AjaxErrorImpl2;
    }();
    AjaxError = AjaxErrorImpl;
    AjaxTimeoutError = AjaxTimeoutErrorImpl;
  }
});

// node_modules/rxjs/_esm5/internal/observable/dom/ajax.js
var ajax;
var init_ajax = __esm({
  "node_modules/rxjs/_esm5/internal/observable/dom/ajax.js"() {
    init_AjaxObservable();
    ajax = function() {
      return AjaxObservable.create;
    }();
  }
});

// node_modules/rxjs/_esm5/internal/observable/dom/WebSocketSubject.js
var DEFAULT_WEBSOCKET_CONFIG, WEBSOCKETSUBJECT_INVALID_ERROR_OBJECT, WebSocketSubject;
var init_WebSocketSubject = __esm({
  "node_modules/rxjs/_esm5/internal/observable/dom/WebSocketSubject.js"() {
    init_tslib_es6();
    init_Subject();
    init_Subscriber();
    init_Observable();
    init_Subscription();
    init_ReplaySubject();
    DEFAULT_WEBSOCKET_CONFIG = {
      url: "",
      deserializer: function(e) {
        return JSON.parse(e.data);
      },
      serializer: function(value) {
        return JSON.stringify(value);
      }
    };
    WEBSOCKETSUBJECT_INVALID_ERROR_OBJECT = "WebSocketSubject.error must be called with an object with an error code, and an optional reason: { code: number, reason: string }";
    WebSocketSubject = function(_super) {
      __extends(WebSocketSubject2, _super);
      function WebSocketSubject2(urlConfigOrSource, destination) {
        var _this = _super.call(this) || this;
        if (urlConfigOrSource instanceof Observable) {
          _this.destination = destination;
          _this.source = urlConfigOrSource;
        } else {
          var config2 = _this._config = __assign({}, DEFAULT_WEBSOCKET_CONFIG);
          _this._output = new Subject();
          if (typeof urlConfigOrSource === "string") {
            config2.url = urlConfigOrSource;
          } else {
            for (var key in urlConfigOrSource) {
              if (urlConfigOrSource.hasOwnProperty(key)) {
                config2[key] = urlConfigOrSource[key];
              }
            }
          }
          if (!config2.WebSocketCtor && WebSocket) {
            config2.WebSocketCtor = WebSocket;
          } else if (!config2.WebSocketCtor) {
            throw new Error("no WebSocket constructor can be found");
          }
          _this.destination = new ReplaySubject();
        }
        return _this;
      }
      WebSocketSubject2.prototype.lift = function(operator) {
        var sock = new WebSocketSubject2(this._config, this.destination);
        sock.operator = operator;
        sock.source = this;
        return sock;
      };
      WebSocketSubject2.prototype._resetState = function() {
        this._socket = null;
        if (!this.source) {
          this.destination = new ReplaySubject();
        }
        this._output = new Subject();
      };
      WebSocketSubject2.prototype.multiplex = function(subMsg, unsubMsg, messageFilter) {
        var self2 = this;
        return new Observable(function(observer) {
          try {
            self2.next(subMsg());
          } catch (err) {
            observer.error(err);
          }
          var subscription = self2.subscribe(function(x) {
            try {
              if (messageFilter(x)) {
                observer.next(x);
              }
            } catch (err) {
              observer.error(err);
            }
          }, function(err) {
            return observer.error(err);
          }, function() {
            return observer.complete();
          });
          return function() {
            try {
              self2.next(unsubMsg());
            } catch (err) {
              observer.error(err);
            }
            subscription.unsubscribe();
          };
        });
      };
      WebSocketSubject2.prototype._connectSocket = function() {
        var _this = this;
        var _a = this._config, WebSocketCtor = _a.WebSocketCtor, protocol = _a.protocol, url = _a.url, binaryType = _a.binaryType;
        var observer = this._output;
        var socket = null;
        try {
          socket = protocol ? new WebSocketCtor(url, protocol) : new WebSocketCtor(url);
          this._socket = socket;
          if (binaryType) {
            this._socket.binaryType = binaryType;
          }
        } catch (e) {
          observer.error(e);
          return;
        }
        var subscription = new Subscription(function() {
          _this._socket = null;
          if (socket && socket.readyState === 1) {
            socket.close();
          }
        });
        socket.onopen = function(e) {
          var _socket = _this._socket;
          if (!_socket) {
            socket.close();
            _this._resetState();
            return;
          }
          var openObserver = _this._config.openObserver;
          if (openObserver) {
            openObserver.next(e);
          }
          var queue = _this.destination;
          _this.destination = Subscriber.create(function(x) {
            if (socket.readyState === 1) {
              try {
                var serializer = _this._config.serializer;
                socket.send(serializer(x));
              } catch (e2) {
                _this.destination.error(e2);
              }
            }
          }, function(e2) {
            var closingObserver = _this._config.closingObserver;
            if (closingObserver) {
              closingObserver.next(void 0);
            }
            if (e2 && e2.code) {
              socket.close(e2.code, e2.reason);
            } else {
              observer.error(new TypeError(WEBSOCKETSUBJECT_INVALID_ERROR_OBJECT));
            }
            _this._resetState();
          }, function() {
            var closingObserver = _this._config.closingObserver;
            if (closingObserver) {
              closingObserver.next(void 0);
            }
            socket.close();
            _this._resetState();
          });
          if (queue && queue instanceof ReplaySubject) {
            subscription.add(queue.subscribe(_this.destination));
          }
        };
        socket.onerror = function(e) {
          _this._resetState();
          observer.error(e);
        };
        socket.onclose = function(e) {
          _this._resetState();
          var closeObserver = _this._config.closeObserver;
          if (closeObserver) {
            closeObserver.next(e);
          }
          if (e.wasClean) {
            observer.complete();
          } else {
            observer.error(e);
          }
        };
        socket.onmessage = function(e) {
          try {
            var deserializer = _this._config.deserializer;
            observer.next(deserializer(e));
          } catch (err) {
            observer.error(err);
          }
        };
      };
      WebSocketSubject2.prototype._subscribe = function(subscriber) {
        var _this = this;
        var source = this.source;
        if (source) {
          return source.subscribe(subscriber);
        }
        if (!this._socket) {
          this._connectSocket();
        }
        this._output.subscribe(subscriber);
        subscriber.add(function() {
          var _socket = _this._socket;
          if (_this._output.observers.length === 0) {
            if (_socket && _socket.readyState === 1) {
              _socket.close();
            }
            _this._resetState();
          }
        });
        return subscriber;
      };
      WebSocketSubject2.prototype.unsubscribe = function() {
        var _socket = this._socket;
        if (_socket && _socket.readyState === 1) {
          _socket.close();
        }
        this._resetState();
        _super.prototype.unsubscribe.call(this);
      };
      return WebSocketSubject2;
    }(AnonymousSubject);
  }
});

// node_modules/rxjs/_esm5/internal/observable/dom/webSocket.js
function webSocket(urlConfigOrSource) {
  return new WebSocketSubject(urlConfigOrSource);
}
var init_webSocket = __esm({
  "node_modules/rxjs/_esm5/internal/observable/dom/webSocket.js"() {
    init_WebSocketSubject();
  }
});

// node_modules/rxjs/_esm5/internal/util/applyMixins.js
function applyMixins(derivedCtor, baseCtors) {
  for (var i = 0, len = baseCtors.length; i < len; i++) {
    var baseCtor = baseCtors[i];
    var propertyKeys = Object.getOwnPropertyNames(baseCtor.prototype);
    for (var j = 0, len2 = propertyKeys.length; j < len2; j++) {
      var name_1 = propertyKeys[j];
      derivedCtor.prototype[name_1] = baseCtor.prototype[name_1];
    }
  }
}
var init_applyMixins = __esm({
  "node_modules/rxjs/_esm5/internal/util/applyMixins.js"() {
  }
});

// node_modules/rxjs/_esm5/internal/util/errorObject.js
var errorObject;
var init_errorObject = __esm({
  "node_modules/rxjs/_esm5/internal/util/errorObject.js"() {
    errorObject = {
      e: {}
    };
  }
});

// node_modules/rxjs/_esm5/internal/util/tryCatch.js
function tryCatcher() {
  errorObject.e = void 0;
  try {
    return tryCatchTarget.apply(this, arguments);
  } catch (e) {
    errorObject.e = e;
    return errorObject;
  } finally {
    tryCatchTarget = void 0;
  }
}
function tryCatch(fn) {
  tryCatchTarget = fn;
  return tryCatcher;
}
var tryCatchTarget;
var init_tryCatch = __esm({
  "node_modules/rxjs/_esm5/internal/util/tryCatch.js"() {
    init_errorObject();
  }
});

// node_modules/rxjs/_esm5/internal-compatibility/index.js
var internal_compatibility_exports = {};
__export(internal_compatibility_exports, {
  AjaxError: () => AjaxError,
  AjaxObservable: () => AjaxObservable,
  AjaxResponse: () => AjaxResponse,
  AjaxSubscriber: () => AjaxSubscriber,
  AjaxTimeoutError: () => AjaxTimeoutError,
  AnonymousSubject: () => AnonymousSubject,
  ArgumentOutOfRangeError: () => ArgumentOutOfRangeError,
  CombineLatestOperator: () => CombineLatestOperator,
  EmptyError: () => EmptyError,
  GroupedObservable: () => GroupedObservable,
  Immediate: () => Immediate,
  InnerSubscriber: () => InnerSubscriber,
  ObjectUnsubscribedError: () => ObjectUnsubscribedError,
  OuterSubscriber: () => OuterSubscriber,
  Scheduler: () => Scheduler,
  SubjectSubscription: () => SubjectSubscription,
  SubscribeOnObservable: () => SubscribeOnObservable,
  Subscriber: () => Subscriber,
  TimeInterval: () => TimeInterval,
  TimeoutError: () => TimeoutError,
  Timestamp: () => Timestamp,
  UnsubscriptionError: () => UnsubscriptionError,
  WebSocketSubject: () => WebSocketSubject,
  ajax: () => ajax,
  ajaxDelete: () => ajaxDelete,
  ajaxGet: () => ajaxGet,
  ajaxGetJSON: () => ajaxGetJSON,
  ajaxPatch: () => ajaxPatch,
  ajaxPost: () => ajaxPost,
  ajaxPut: () => ajaxPut,
  applyMixins: () => applyMixins,
  config: () => config,
  defaultThrottleConfig: () => defaultThrottleConfig,
  dispatch: () => dispatch,
  errorObject: () => errorObject,
  fromIterable: () => fromIterable,
  fromPromise: () => fromPromise,
  hostReportError: () => hostReportError,
  identity: () => identity,
  isArray: () => isArray,
  isArrayLike: () => isArrayLike,
  isDate: () => isDate,
  isFunction: () => isFunction,
  isIterable: () => isIterable,
  isNumeric: () => isNumeric,
  isObject: () => isObject,
  isObservable: () => isInteropObservable,
  isPromise: () => isPromise,
  isScheduler: () => isScheduler,
  iterator: () => iterator,
  noop: () => noop,
  not: () => not,
  observable: () => observable,
  pipe: () => pipe,
  root: () => _root,
  rxSubscriber: () => rxSubscriber,
  subscribeTo: () => subscribeTo,
  subscribeToArray: () => subscribeToArray,
  subscribeToIterable: () => subscribeToIterable,
  subscribeToObservable: () => subscribeToObservable,
  subscribeToPromise: () => subscribeToPromise,
  subscribeToResult: () => subscribeToResult,
  toSubscriber: () => toSubscriber,
  tryCatch: () => tryCatch,
  webSocket: () => webSocket
});
var init_internal_compatibility = __esm({
  "node_modules/rxjs/_esm5/internal-compatibility/index.js"() {
    init_config();
    init_InnerSubscriber();
    init_OuterSubscriber();
    init_Scheduler();
    init_Subject();
    init_SubjectSubscription();
    init_Subscriber();
    init_fromPromise();
    init_fromIterable();
    init_ajax();
    init_webSocket();
    init_AjaxObservable();
    init_WebSocketSubject();
    init_combineLatest();
    init_range();
    init_SubscribeOnObservable();
    init_timestamp();
    init_timeInterval();
    init_groupBy();
    init_throttle();
    init_rxSubscriber();
    init_iterator();
    init_observable();
    init_ArgumentOutOfRangeError();
    init_EmptyError();
    init_Immediate();
    init_ObjectUnsubscribedError();
    init_TimeoutError();
    init_UnsubscriptionError();
    init_applyMixins();
    init_errorObject();
    init_hostReportError();
    init_identity();
    init_isArray();
    init_isArrayLike();
    init_isDate();
    init_isFunction();
    init_isIterable();
    init_isNumeric();
    init_isObject();
    init_isInteropObservable();
    init_isPromise();
    init_isScheduler();
    init_noop();
    init_not();
    init_pipe();
    init_root();
    init_subscribeTo();
    init_subscribeToArray();
    init_subscribeToIterable();
    init_subscribeToObservable();
    init_subscribeToPromise();
    init_subscribeToResult();
    init_toSubscriber();
    init_tryCatch();
  }
});

// node_modules/rxjs-compat/add/observable/bindCallback.js
var require_bindCallback = __commonJS({
  "node_modules/rxjs-compat/add/observable/bindCallback.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.bindCallback = rxjs_1.bindCallback;
  }
});

// node_modules/rxjs-compat/add/observable/bindNodeCallback.js
var require_bindNodeCallback = __commonJS({
  "node_modules/rxjs-compat/add/observable/bindNodeCallback.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.bindNodeCallback = rxjs_1.bindNodeCallback;
  }
});

// node_modules/rxjs-compat/add/observable/combineLatest.js
var require_combineLatest = __commonJS({
  "node_modules/rxjs-compat/add/observable/combineLatest.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.combineLatest = rxjs_1.combineLatest;
  }
});

// node_modules/rxjs-compat/add/observable/concat.js
var require_concat = __commonJS({
  "node_modules/rxjs-compat/add/observable/concat.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.concat = rxjs_1.concat;
  }
});

// node_modules/rxjs-compat/add/observable/defer.js
var require_defer = __commonJS({
  "node_modules/rxjs-compat/add/observable/defer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.defer = rxjs_1.defer;
  }
});

// node_modules/rxjs-compat/add/observable/empty.js
var require_empty = __commonJS({
  "node_modules/rxjs-compat/add/observable/empty.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.empty = rxjs_1.empty;
  }
});

// node_modules/rxjs-compat/add/observable/forkJoin.js
var require_forkJoin = __commonJS({
  "node_modules/rxjs-compat/add/observable/forkJoin.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.forkJoin = rxjs_1.forkJoin;
  }
});

// node_modules/rxjs-compat/add/observable/from.js
var require_from = __commonJS({
  "node_modules/rxjs-compat/add/observable/from.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.from = rxjs_1.from;
  }
});

// node_modules/rxjs-compat/add/observable/fromEvent.js
var require_fromEvent = __commonJS({
  "node_modules/rxjs-compat/add/observable/fromEvent.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.fromEvent = rxjs_1.fromEvent;
  }
});

// node_modules/rxjs-compat/add/observable/fromEventPattern.js
var require_fromEventPattern = __commonJS({
  "node_modules/rxjs-compat/add/observable/fromEventPattern.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.fromEventPattern = rxjs_1.fromEventPattern;
  }
});

// node_modules/rxjs-compat/add/observable/fromPromise.js
var require_fromPromise = __commonJS({
  "node_modules/rxjs-compat/add/observable/fromPromise.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.fromPromise = rxjs_1.from;
  }
});

// node_modules/rxjs-compat/add/observable/generate.js
var require_generate = __commonJS({
  "node_modules/rxjs-compat/add/observable/generate.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.generate = rxjs_1.generate;
  }
});

// node_modules/rxjs-compat/add/observable/if.js
var require_if = __commonJS({
  "node_modules/rxjs-compat/add/observable/if.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.if = rxjs_1.iif;
  }
});

// node_modules/rxjs-compat/add/observable/interval.js
var require_interval = __commonJS({
  "node_modules/rxjs-compat/add/observable/interval.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.interval = rxjs_1.interval;
  }
});

// node_modules/rxjs-compat/add/observable/merge.js
var require_merge = __commonJS({
  "node_modules/rxjs-compat/add/observable/merge.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.merge = rxjs_1.merge;
  }
});

// node_modules/rxjs-compat/add/observable/race.js
var require_race = __commonJS({
  "node_modules/rxjs-compat/add/observable/race.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.race = rxjs_1.race;
  }
});

// node_modules/rxjs-compat/add/observable/never.js
var require_never = __commonJS({
  "node_modules/rxjs-compat/add/observable/never.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    function staticNever() {
      return rxjs_1.NEVER;
    }
    exports.staticNever = staticNever;
    rxjs_1.Observable.never = staticNever;
  }
});

// node_modules/rxjs-compat/add/observable/of.js
var require_of = __commonJS({
  "node_modules/rxjs-compat/add/observable/of.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.of = rxjs_1.of;
  }
});

// node_modules/rxjs-compat/add/observable/onErrorResumeNext.js
var require_onErrorResumeNext = __commonJS({
  "node_modules/rxjs-compat/add/observable/onErrorResumeNext.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.onErrorResumeNext = rxjs_1.onErrorResumeNext;
  }
});

// node_modules/rxjs-compat/add/observable/pairs.js
var require_pairs = __commonJS({
  "node_modules/rxjs-compat/add/observable/pairs.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.pairs = rxjs_1.pairs;
  }
});

// node_modules/rxjs-compat/add/observable/range.js
var require_range = __commonJS({
  "node_modules/rxjs-compat/add/observable/range.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.range = rxjs_1.range;
  }
});

// node_modules/rxjs-compat/add/observable/using.js
var require_using = __commonJS({
  "node_modules/rxjs-compat/add/observable/using.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.using = rxjs_1.using;
  }
});

// node_modules/rxjs-compat/add/observable/throw.js
var require_throw = __commonJS({
  "node_modules/rxjs-compat/add/observable/throw.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.throw = rxjs_1.throwError;
    rxjs_1.Observable.throwError = rxjs_1.throwError;
  }
});

// node_modules/rxjs-compat/add/observable/timer.js
var require_timer = __commonJS({
  "node_modules/rxjs-compat/add/observable/timer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.timer = rxjs_1.timer;
  }
});

// node_modules/rxjs-compat/add/observable/zip.js
var require_zip = __commonJS({
  "node_modules/rxjs-compat/add/observable/zip.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    rxjs_1.Observable.zip = rxjs_1.zip;
  }
});

// node_modules/rxjs/_esm5/ajax/index.js
var ajax_exports = {};
__export(ajax_exports, {
  AjaxError: () => AjaxError,
  AjaxResponse: () => AjaxResponse,
  AjaxTimeoutError: () => AjaxTimeoutError,
  ajax: () => ajax
});
var init_ajax2 = __esm({
  "node_modules/rxjs/_esm5/ajax/index.js"() {
    init_ajax();
    init_AjaxObservable();
  }
});

// node_modules/rxjs-compat/add/observable/dom/ajax.js
var require_ajax = __commonJS({
  "node_modules/rxjs-compat/add/observable/dom/ajax.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var ajax_1 = (init_ajax2(), __toCommonJS(ajax_exports));
    rxjs_1.Observable.ajax = ajax_1.ajax;
  }
});

// node_modules/rxjs/_esm5/webSocket/index.js
var webSocket_exports = {};
__export(webSocket_exports, {
  WebSocketSubject: () => WebSocketSubject,
  webSocket: () => webSocket
});
var init_webSocket2 = __esm({
  "node_modules/rxjs/_esm5/webSocket/index.js"() {
    init_webSocket();
    init_WebSocketSubject();
  }
});

// node_modules/rxjs-compat/add/observable/dom/webSocket.js
var require_webSocket = __commonJS({
  "node_modules/rxjs-compat/add/observable/dom/webSocket.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var webSocket_1 = (init_webSocket2(), __toCommonJS(webSocket_exports));
    rxjs_1.Observable.webSocket = webSocket_1.webSocket;
  }
});

// node_modules/rxjs-compat/operator/buffer.js
var require_buffer = __commonJS({
  "node_modules/rxjs-compat/operator/buffer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function buffer(closingNotifier) {
      return operators_1.buffer(closingNotifier)(this);
    }
    exports.buffer = buffer;
  }
});

// node_modules/rxjs-compat/add/operator/buffer.js
var require_buffer2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/buffer.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var buffer_1 = require_buffer();
    rxjs_1.Observable.prototype.buffer = buffer_1.buffer;
  }
});

// node_modules/rxjs-compat/operator/bufferCount.js
var require_bufferCount = __commonJS({
  "node_modules/rxjs-compat/operator/bufferCount.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function bufferCount(bufferSize, startBufferEvery) {
      if (startBufferEvery === void 0) {
        startBufferEvery = null;
      }
      return operators_1.bufferCount(bufferSize, startBufferEvery)(this);
    }
    exports.bufferCount = bufferCount;
  }
});

// node_modules/rxjs-compat/add/operator/bufferCount.js
var require_bufferCount2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/bufferCount.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var bufferCount_1 = require_bufferCount();
    rxjs_1.Observable.prototype.bufferCount = bufferCount_1.bufferCount;
  }
});

// node_modules/rxjs-compat/operator/bufferTime.js
var require_bufferTime = __commonJS({
  "node_modules/rxjs-compat/operator/bufferTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var internal_compatibility_1 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function bufferTime(bufferTimeSpan) {
      var length = arguments.length;
      var scheduler = rxjs_1.asyncScheduler;
      if (internal_compatibility_1.isScheduler(arguments[arguments.length - 1])) {
        scheduler = arguments[arguments.length - 1];
        length--;
      }
      var bufferCreationInterval = null;
      if (length >= 2) {
        bufferCreationInterval = arguments[1];
      }
      var maxBufferSize = Number.POSITIVE_INFINITY;
      if (length >= 3) {
        maxBufferSize = arguments[2];
      }
      return operators_1.bufferTime(bufferTimeSpan, bufferCreationInterval, maxBufferSize, scheduler)(this);
    }
    exports.bufferTime = bufferTime;
  }
});

// node_modules/rxjs-compat/add/operator/bufferTime.js
var require_bufferTime2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/bufferTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var bufferTime_1 = require_bufferTime();
    rxjs_1.Observable.prototype.bufferTime = bufferTime_1.bufferTime;
  }
});

// node_modules/rxjs-compat/operator/bufferToggle.js
var require_bufferToggle = __commonJS({
  "node_modules/rxjs-compat/operator/bufferToggle.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function bufferToggle(openings, closingSelector) {
      return operators_1.bufferToggle(openings, closingSelector)(this);
    }
    exports.bufferToggle = bufferToggle;
  }
});

// node_modules/rxjs-compat/add/operator/bufferToggle.js
var require_bufferToggle2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/bufferToggle.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var bufferToggle_1 = require_bufferToggle();
    rxjs_1.Observable.prototype.bufferToggle = bufferToggle_1.bufferToggle;
  }
});

// node_modules/rxjs-compat/operator/bufferWhen.js
var require_bufferWhen = __commonJS({
  "node_modules/rxjs-compat/operator/bufferWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function bufferWhen(closingSelector) {
      return operators_1.bufferWhen(closingSelector)(this);
    }
    exports.bufferWhen = bufferWhen;
  }
});

// node_modules/rxjs-compat/add/operator/bufferWhen.js
var require_bufferWhen2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/bufferWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var bufferWhen_1 = require_bufferWhen();
    rxjs_1.Observable.prototype.bufferWhen = bufferWhen_1.bufferWhen;
  }
});

// node_modules/rxjs-compat/operator/catch.js
var require_catch = __commonJS({
  "node_modules/rxjs-compat/operator/catch.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function _catch(selector) {
      return operators_1.catchError(selector)(this);
    }
    exports._catch = _catch;
  }
});

// node_modules/rxjs-compat/add/operator/catch.js
var require_catch2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/catch.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var catch_1 = require_catch();
    rxjs_1.Observable.prototype.catch = catch_1._catch;
    rxjs_1.Observable.prototype._catch = catch_1._catch;
  }
});

// node_modules/rxjs-compat/operator/combineAll.js
var require_combineAll = __commonJS({
  "node_modules/rxjs-compat/operator/combineAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function combineAll(project) {
      return operators_1.combineAll(project)(this);
    }
    exports.combineAll = combineAll;
  }
});

// node_modules/rxjs-compat/add/operator/combineAll.js
var require_combineAll2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/combineAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var combineAll_1 = require_combineAll();
    rxjs_1.Observable.prototype.combineAll = combineAll_1.combineAll;
  }
});

// node_modules/rxjs-compat/operator/combineLatest.js
var require_combineLatest2 = __commonJS({
  "node_modules/rxjs-compat/operator/combineLatest.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var internal_compatibility_1 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    function combineLatest() {
      var observables = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        observables[_i] = arguments[_i];
      }
      var project = null;
      if (typeof observables[observables.length - 1] === "function") {
        project = observables.pop();
      }
      if (observables.length === 1 && internal_compatibility_1.isArray(observables[0])) {
        observables = observables[0].slice();
      }
      return this.lift.call(rxjs_1.of.apply(void 0, [this].concat(observables)), new internal_compatibility_1.CombineLatestOperator(project));
    }
    exports.combineLatest = combineLatest;
  }
});

// node_modules/rxjs-compat/add/operator/combineLatest.js
var require_combineLatest3 = __commonJS({
  "node_modules/rxjs-compat/add/operator/combineLatest.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var combineLatest_1 = require_combineLatest2();
    rxjs_1.Observable.prototype.combineLatest = combineLatest_1.combineLatest;
  }
});

// node_modules/rxjs-compat/operator/concat.js
var require_concat2 = __commonJS({
  "node_modules/rxjs-compat/operator/concat.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    function concat() {
      var observables = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        observables[_i] = arguments[_i];
      }
      return this.lift.call(rxjs_1.concat.apply(void 0, [this].concat(observables)));
    }
    exports.concat = concat;
  }
});

// node_modules/rxjs-compat/add/operator/concat.js
var require_concat3 = __commonJS({
  "node_modules/rxjs-compat/add/operator/concat.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var concat_1 = require_concat2();
    rxjs_1.Observable.prototype.concat = concat_1.concat;
  }
});

// node_modules/rxjs-compat/operator/concatAll.js
var require_concatAll = __commonJS({
  "node_modules/rxjs-compat/operator/concatAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function concatAll() {
      return operators_1.concatAll()(this);
    }
    exports.concatAll = concatAll;
  }
});

// node_modules/rxjs-compat/add/operator/concatAll.js
var require_concatAll2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/concatAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var concatAll_1 = require_concatAll();
    rxjs_1.Observable.prototype.concatAll = concatAll_1.concatAll;
  }
});

// node_modules/rxjs-compat/operator/concatMap.js
var require_concatMap = __commonJS({
  "node_modules/rxjs-compat/operator/concatMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function concatMap(project) {
      return operators_1.concatMap(project)(this);
    }
    exports.concatMap = concatMap;
  }
});

// node_modules/rxjs-compat/add/operator/concatMap.js
var require_concatMap2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/concatMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var concatMap_1 = require_concatMap();
    rxjs_1.Observable.prototype.concatMap = concatMap_1.concatMap;
  }
});

// node_modules/rxjs-compat/operator/concatMapTo.js
var require_concatMapTo = __commonJS({
  "node_modules/rxjs-compat/operator/concatMapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function concatMapTo(innerObservable) {
      return operators_1.concatMapTo(innerObservable)(this);
    }
    exports.concatMapTo = concatMapTo;
  }
});

// node_modules/rxjs-compat/add/operator/concatMapTo.js
var require_concatMapTo2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/concatMapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var concatMapTo_1 = require_concatMapTo();
    rxjs_1.Observable.prototype.concatMapTo = concatMapTo_1.concatMapTo;
  }
});

// node_modules/rxjs-compat/operator/count.js
var require_count = __commonJS({
  "node_modules/rxjs-compat/operator/count.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function count(predicate) {
      return operators_1.count(predicate)(this);
    }
    exports.count = count;
  }
});

// node_modules/rxjs-compat/add/operator/count.js
var require_count2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/count.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var count_1 = require_count();
    rxjs_1.Observable.prototype.count = count_1.count;
  }
});

// node_modules/rxjs-compat/operator/dematerialize.js
var require_dematerialize = __commonJS({
  "node_modules/rxjs-compat/operator/dematerialize.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function dematerialize() {
      return operators_1.dematerialize()(this);
    }
    exports.dematerialize = dematerialize;
  }
});

// node_modules/rxjs-compat/add/operator/dematerialize.js
var require_dematerialize2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/dematerialize.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var dematerialize_1 = require_dematerialize();
    rxjs_1.Observable.prototype.dematerialize = dematerialize_1.dematerialize;
  }
});

// node_modules/rxjs-compat/operator/debounce.js
var require_debounce = __commonJS({
  "node_modules/rxjs-compat/operator/debounce.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function debounce(durationSelector) {
      return operators_1.debounce(durationSelector)(this);
    }
    exports.debounce = debounce;
  }
});

// node_modules/rxjs-compat/add/operator/debounce.js
var require_debounce2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/debounce.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var debounce_1 = require_debounce();
    rxjs_1.Observable.prototype.debounce = debounce_1.debounce;
  }
});

// node_modules/rxjs-compat/operator/debounceTime.js
var require_debounceTime = __commonJS({
  "node_modules/rxjs-compat/operator/debounceTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function debounceTime(dueTime, scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.debounceTime(dueTime, scheduler)(this);
    }
    exports.debounceTime = debounceTime;
  }
});

// node_modules/rxjs-compat/add/operator/debounceTime.js
var require_debounceTime2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/debounceTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var debounceTime_1 = require_debounceTime();
    rxjs_1.Observable.prototype.debounceTime = debounceTime_1.debounceTime;
  }
});

// node_modules/rxjs-compat/operator/defaultIfEmpty.js
var require_defaultIfEmpty = __commonJS({
  "node_modules/rxjs-compat/operator/defaultIfEmpty.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function defaultIfEmpty(defaultValue) {
      if (defaultValue === void 0) {
        defaultValue = null;
      }
      return operators_1.defaultIfEmpty(defaultValue)(this);
    }
    exports.defaultIfEmpty = defaultIfEmpty;
  }
});

// node_modules/rxjs-compat/add/operator/defaultIfEmpty.js
var require_defaultIfEmpty2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/defaultIfEmpty.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var defaultIfEmpty_1 = require_defaultIfEmpty();
    rxjs_1.Observable.prototype.defaultIfEmpty = defaultIfEmpty_1.defaultIfEmpty;
  }
});

// node_modules/rxjs-compat/operator/delay.js
var require_delay = __commonJS({
  "node_modules/rxjs-compat/operator/delay.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function delay(delay2, scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.delay(delay2, scheduler)(this);
    }
    exports.delay = delay;
  }
});

// node_modules/rxjs-compat/add/operator/delay.js
var require_delay2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/delay.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var delay_1 = require_delay();
    rxjs_1.Observable.prototype.delay = delay_1.delay;
  }
});

// node_modules/rxjs-compat/operator/delayWhen.js
var require_delayWhen = __commonJS({
  "node_modules/rxjs-compat/operator/delayWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function delayWhen(delayDurationSelector, subscriptionDelay) {
      return operators_1.delayWhen(delayDurationSelector, subscriptionDelay)(this);
    }
    exports.delayWhen = delayWhen;
  }
});

// node_modules/rxjs-compat/add/operator/delayWhen.js
var require_delayWhen2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/delayWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var delayWhen_1 = require_delayWhen();
    rxjs_1.Observable.prototype.delayWhen = delayWhen_1.delayWhen;
  }
});

// node_modules/rxjs-compat/operator/distinct.js
var require_distinct = __commonJS({
  "node_modules/rxjs-compat/operator/distinct.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function distinct(keySelector, flushes) {
      return operators_1.distinct(keySelector, flushes)(this);
    }
    exports.distinct = distinct;
  }
});

// node_modules/rxjs-compat/add/operator/distinct.js
var require_distinct2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/distinct.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var distinct_1 = require_distinct();
    rxjs_1.Observable.prototype.distinct = distinct_1.distinct;
  }
});

// node_modules/rxjs-compat/operator/distinctUntilChanged.js
var require_distinctUntilChanged = __commonJS({
  "node_modules/rxjs-compat/operator/distinctUntilChanged.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function distinctUntilChanged(compare, keySelector) {
      return operators_1.distinctUntilChanged(compare, keySelector)(this);
    }
    exports.distinctUntilChanged = distinctUntilChanged;
  }
});

// node_modules/rxjs-compat/add/operator/distinctUntilChanged.js
var require_distinctUntilChanged2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/distinctUntilChanged.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var distinctUntilChanged_1 = require_distinctUntilChanged();
    rxjs_1.Observable.prototype.distinctUntilChanged = distinctUntilChanged_1.distinctUntilChanged;
  }
});

// node_modules/rxjs-compat/operator/distinctUntilKeyChanged.js
var require_distinctUntilKeyChanged = __commonJS({
  "node_modules/rxjs-compat/operator/distinctUntilKeyChanged.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function distinctUntilKeyChanged(key, compare) {
      return operators_1.distinctUntilKeyChanged(key, compare)(this);
    }
    exports.distinctUntilKeyChanged = distinctUntilKeyChanged;
  }
});

// node_modules/rxjs-compat/add/operator/distinctUntilKeyChanged.js
var require_distinctUntilKeyChanged2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/distinctUntilKeyChanged.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var distinctUntilKeyChanged_1 = require_distinctUntilKeyChanged();
    rxjs_1.Observable.prototype.distinctUntilKeyChanged = distinctUntilKeyChanged_1.distinctUntilKeyChanged;
  }
});

// node_modules/rxjs-compat/operator/do.js
var require_do = __commonJS({
  "node_modules/rxjs-compat/operator/do.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function _do(nextOrObserver, error, complete) {
      return operators_1.tap(nextOrObserver, error, complete)(this);
    }
    exports._do = _do;
  }
});

// node_modules/rxjs-compat/add/operator/do.js
var require_do2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/do.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var do_1 = require_do();
    rxjs_1.Observable.prototype.do = do_1._do;
    rxjs_1.Observable.prototype._do = do_1._do;
  }
});

// node_modules/rxjs-compat/operator/exhaust.js
var require_exhaust = __commonJS({
  "node_modules/rxjs-compat/operator/exhaust.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function exhaust() {
      return operators_1.exhaust()(this);
    }
    exports.exhaust = exhaust;
  }
});

// node_modules/rxjs-compat/add/operator/exhaust.js
var require_exhaust2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/exhaust.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var exhaust_1 = require_exhaust();
    rxjs_1.Observable.prototype.exhaust = exhaust_1.exhaust;
  }
});

// node_modules/rxjs-compat/operator/exhaustMap.js
var require_exhaustMap = __commonJS({
  "node_modules/rxjs-compat/operator/exhaustMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function exhaustMap(project) {
      return operators_1.exhaustMap(project)(this);
    }
    exports.exhaustMap = exhaustMap;
  }
});

// node_modules/rxjs-compat/add/operator/exhaustMap.js
var require_exhaustMap2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/exhaustMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var exhaustMap_1 = require_exhaustMap();
    rxjs_1.Observable.prototype.exhaustMap = exhaustMap_1.exhaustMap;
  }
});

// node_modules/rxjs-compat/operator/expand.js
var require_expand = __commonJS({
  "node_modules/rxjs-compat/operator/expand.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function expand(project, concurrent, scheduler) {
      if (concurrent === void 0) {
        concurrent = Number.POSITIVE_INFINITY;
      }
      if (scheduler === void 0) {
        scheduler = void 0;
      }
      concurrent = (concurrent || 0) < 1 ? Number.POSITIVE_INFINITY : concurrent;
      return operators_1.expand(project, concurrent, scheduler)(this);
    }
    exports.expand = expand;
  }
});

// node_modules/rxjs-compat/add/operator/expand.js
var require_expand2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/expand.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var expand_1 = require_expand();
    rxjs_1.Observable.prototype.expand = expand_1.expand;
  }
});

// node_modules/rxjs-compat/operator/elementAt.js
var require_elementAt = __commonJS({
  "node_modules/rxjs-compat/operator/elementAt.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function elementAt(index, defaultValue) {
      return operators_1.elementAt.apply(void 0, arguments)(this);
    }
    exports.elementAt = elementAt;
  }
});

// node_modules/rxjs-compat/add/operator/elementAt.js
var require_elementAt2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/elementAt.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var elementAt_1 = require_elementAt();
    rxjs_1.Observable.prototype.elementAt = elementAt_1.elementAt;
  }
});

// node_modules/rxjs-compat/operator/filter.js
var require_filter = __commonJS({
  "node_modules/rxjs-compat/operator/filter.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function filter(predicate, thisArg) {
      return operators_1.filter(predicate, thisArg)(this);
    }
    exports.filter = filter;
  }
});

// node_modules/rxjs-compat/add/operator/filter.js
var require_filter2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/filter.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var filter_1 = require_filter();
    rxjs_1.Observable.prototype.filter = filter_1.filter;
  }
});

// node_modules/rxjs-compat/operator/finally.js
var require_finally = __commonJS({
  "node_modules/rxjs-compat/operator/finally.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function _finally(callback) {
      return operators_1.finalize(callback)(this);
    }
    exports._finally = _finally;
  }
});

// node_modules/rxjs-compat/add/operator/finally.js
var require_finally2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/finally.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var finally_1 = require_finally();
    rxjs_1.Observable.prototype.finally = finally_1._finally;
    rxjs_1.Observable.prototype._finally = finally_1._finally;
  }
});

// node_modules/rxjs-compat/operator/find.js
var require_find = __commonJS({
  "node_modules/rxjs-compat/operator/find.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function find(predicate, thisArg) {
      return operators_1.find(predicate, thisArg)(this);
    }
    exports.find = find;
  }
});

// node_modules/rxjs-compat/add/operator/find.js
var require_find2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/find.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var find_1 = require_find();
    rxjs_1.Observable.prototype.find = find_1.find;
  }
});

// node_modules/rxjs-compat/operator/findIndex.js
var require_findIndex = __commonJS({
  "node_modules/rxjs-compat/operator/findIndex.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function findIndex(predicate, thisArg) {
      return operators_1.findIndex(predicate, thisArg)(this);
    }
    exports.findIndex = findIndex;
  }
});

// node_modules/rxjs-compat/add/operator/findIndex.js
var require_findIndex2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/findIndex.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var findIndex_1 = require_findIndex();
    rxjs_1.Observable.prototype.findIndex = findIndex_1.findIndex;
  }
});

// node_modules/rxjs-compat/operator/first.js
var require_first = __commonJS({
  "node_modules/rxjs-compat/operator/first.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function first() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return operators_1.first.apply(void 0, args)(this);
    }
    exports.first = first;
  }
});

// node_modules/rxjs-compat/add/operator/first.js
var require_first2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/first.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var first_1 = require_first();
    rxjs_1.Observable.prototype.first = first_1.first;
  }
});

// node_modules/rxjs-compat/operator/groupBy.js
var require_groupBy = __commonJS({
  "node_modules/rxjs-compat/operator/groupBy.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function groupBy(keySelector, elementSelector, durationSelector, subjectSelector) {
      return operators_1.groupBy(keySelector, elementSelector, durationSelector, subjectSelector)(this);
    }
    exports.groupBy = groupBy;
  }
});

// node_modules/rxjs-compat/add/operator/groupBy.js
var require_groupBy2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/groupBy.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var groupBy_1 = require_groupBy();
    rxjs_1.Observable.prototype.groupBy = groupBy_1.groupBy;
  }
});

// node_modules/rxjs-compat/operator/ignoreElements.js
var require_ignoreElements = __commonJS({
  "node_modules/rxjs-compat/operator/ignoreElements.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function ignoreElements() {
      return operators_1.ignoreElements()(this);
    }
    exports.ignoreElements = ignoreElements;
  }
});

// node_modules/rxjs-compat/add/operator/ignoreElements.js
var require_ignoreElements2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/ignoreElements.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var ignoreElements_1 = require_ignoreElements();
    rxjs_1.Observable.prototype.ignoreElements = ignoreElements_1.ignoreElements;
  }
});

// node_modules/rxjs-compat/operator/isEmpty.js
var require_isEmpty = __commonJS({
  "node_modules/rxjs-compat/operator/isEmpty.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function isEmpty() {
      return operators_1.isEmpty()(this);
    }
    exports.isEmpty = isEmpty;
  }
});

// node_modules/rxjs-compat/add/operator/isEmpty.js
var require_isEmpty2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/isEmpty.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var isEmpty_1 = require_isEmpty();
    rxjs_1.Observable.prototype.isEmpty = isEmpty_1.isEmpty;
  }
});

// node_modules/rxjs-compat/operator/audit.js
var require_audit = __commonJS({
  "node_modules/rxjs-compat/operator/audit.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function audit(durationSelector) {
      return operators_1.audit(durationSelector)(this);
    }
    exports.audit = audit;
  }
});

// node_modules/rxjs-compat/add/operator/audit.js
var require_audit2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/audit.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var audit_1 = require_audit();
    rxjs_1.Observable.prototype.audit = audit_1.audit;
  }
});

// node_modules/rxjs-compat/operator/auditTime.js
var require_auditTime = __commonJS({
  "node_modules/rxjs-compat/operator/auditTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function auditTime(duration, scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.auditTime(duration, scheduler)(this);
    }
    exports.auditTime = auditTime;
  }
});

// node_modules/rxjs-compat/add/operator/auditTime.js
var require_auditTime2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/auditTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var auditTime_1 = require_auditTime();
    rxjs_1.Observable.prototype.auditTime = auditTime_1.auditTime;
  }
});

// node_modules/rxjs-compat/operator/last.js
var require_last = __commonJS({
  "node_modules/rxjs-compat/operator/last.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function last() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return operators_1.last.apply(void 0, args)(this);
    }
    exports.last = last;
  }
});

// node_modules/rxjs-compat/add/operator/last.js
var require_last2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/last.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var last_1 = require_last();
    rxjs_1.Observable.prototype.last = last_1.last;
  }
});

// node_modules/rxjs-compat/operator/let.js
var require_let = __commonJS({
  "node_modules/rxjs-compat/operator/let.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    function letProto(func) {
      return func(this);
    }
    exports.letProto = letProto;
  }
});

// node_modules/rxjs-compat/add/operator/let.js
var require_let2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/let.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var let_1 = require_let();
    rxjs_1.Observable.prototype.let = let_1.letProto;
    rxjs_1.Observable.prototype.letBind = let_1.letProto;
  }
});

// node_modules/rxjs-compat/operator/every.js
var require_every = __commonJS({
  "node_modules/rxjs-compat/operator/every.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function every(predicate, thisArg) {
      return operators_1.every(predicate, thisArg)(this);
    }
    exports.every = every;
  }
});

// node_modules/rxjs-compat/add/operator/every.js
var require_every2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/every.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var every_1 = require_every();
    rxjs_1.Observable.prototype.every = every_1.every;
  }
});

// node_modules/rxjs-compat/operator/map.js
var require_map = __commonJS({
  "node_modules/rxjs-compat/operator/map.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function map2(project, thisArg) {
      return operators_1.map(project, thisArg)(this);
    }
    exports.map = map2;
  }
});

// node_modules/rxjs-compat/add/operator/map.js
var require_map2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/map.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var map_1 = require_map();
    rxjs_1.Observable.prototype.map = map_1.map;
  }
});

// node_modules/rxjs-compat/operator/mapTo.js
var require_mapTo = __commonJS({
  "node_modules/rxjs-compat/operator/mapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function mapTo(value) {
      return operators_1.mapTo(value)(this);
    }
    exports.mapTo = mapTo;
  }
});

// node_modules/rxjs-compat/add/operator/mapTo.js
var require_mapTo2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/mapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var mapTo_1 = require_mapTo();
    rxjs_1.Observable.prototype.mapTo = mapTo_1.mapTo;
  }
});

// node_modules/rxjs-compat/operator/materialize.js
var require_materialize = __commonJS({
  "node_modules/rxjs-compat/operator/materialize.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function materialize() {
      return operators_1.materialize()(this);
    }
    exports.materialize = materialize;
  }
});

// node_modules/rxjs-compat/add/operator/materialize.js
var require_materialize2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/materialize.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var materialize_1 = require_materialize();
    rxjs_1.Observable.prototype.materialize = materialize_1.materialize;
  }
});

// node_modules/rxjs-compat/operator/max.js
var require_max = __commonJS({
  "node_modules/rxjs-compat/operator/max.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function max(comparer) {
      return operators_1.max(comparer)(this);
    }
    exports.max = max;
  }
});

// node_modules/rxjs-compat/add/operator/max.js
var require_max2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/max.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var max_1 = require_max();
    rxjs_1.Observable.prototype.max = max_1.max;
  }
});

// node_modules/rxjs-compat/operator/merge.js
var require_merge2 = __commonJS({
  "node_modules/rxjs-compat/operator/merge.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    function merge() {
      var observables = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        observables[_i] = arguments[_i];
      }
      return this.lift.call(rxjs_1.merge.apply(void 0, [this].concat(observables)));
    }
    exports.merge = merge;
  }
});

// node_modules/rxjs-compat/add/operator/merge.js
var require_merge3 = __commonJS({
  "node_modules/rxjs-compat/add/operator/merge.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var merge_1 = require_merge2();
    rxjs_1.Observable.prototype.merge = merge_1.merge;
  }
});

// node_modules/rxjs-compat/operator/mergeAll.js
var require_mergeAll = __commonJS({
  "node_modules/rxjs-compat/operator/mergeAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function mergeAll(concurrent) {
      if (concurrent === void 0) {
        concurrent = Number.POSITIVE_INFINITY;
      }
      return operators_1.mergeAll(concurrent)(this);
    }
    exports.mergeAll = mergeAll;
  }
});

// node_modules/rxjs-compat/add/operator/mergeAll.js
var require_mergeAll2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/mergeAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var mergeAll_1 = require_mergeAll();
    rxjs_1.Observable.prototype.mergeAll = mergeAll_1.mergeAll;
  }
});

// node_modules/rxjs-compat/operator/mergeMap.js
var require_mergeMap = __commonJS({
  "node_modules/rxjs-compat/operator/mergeMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function mergeMap(project, concurrent) {
      if (concurrent === void 0) {
        concurrent = Number.POSITIVE_INFINITY;
      }
      return operators_1.mergeMap(project, concurrent)(this);
    }
    exports.mergeMap = mergeMap;
  }
});

// node_modules/rxjs-compat/add/operator/mergeMap.js
var require_mergeMap2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/mergeMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var mergeMap_1 = require_mergeMap();
    rxjs_1.Observable.prototype.mergeMap = mergeMap_1.mergeMap;
    rxjs_1.Observable.prototype.flatMap = mergeMap_1.mergeMap;
  }
});

// node_modules/rxjs-compat/operator/mergeMapTo.js
var require_mergeMapTo = __commonJS({
  "node_modules/rxjs-compat/operator/mergeMapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function mergeMapTo(innerObservable, concurrent) {
      if (concurrent === void 0) {
        concurrent = Number.POSITIVE_INFINITY;
      }
      return operators_1.mergeMapTo(innerObservable, concurrent)(this);
    }
    exports.mergeMapTo = mergeMapTo;
  }
});

// node_modules/rxjs-compat/add/operator/mergeMapTo.js
var require_mergeMapTo2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/mergeMapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var mergeMapTo_1 = require_mergeMapTo();
    rxjs_1.Observable.prototype.flatMapTo = mergeMapTo_1.mergeMapTo;
    rxjs_1.Observable.prototype.mergeMapTo = mergeMapTo_1.mergeMapTo;
  }
});

// node_modules/rxjs-compat/operator/mergeScan.js
var require_mergeScan = __commonJS({
  "node_modules/rxjs-compat/operator/mergeScan.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function mergeScan(accumulator, seed, concurrent) {
      if (concurrent === void 0) {
        concurrent = Number.POSITIVE_INFINITY;
      }
      return operators_1.mergeScan(accumulator, seed, concurrent)(this);
    }
    exports.mergeScan = mergeScan;
  }
});

// node_modules/rxjs-compat/add/operator/mergeScan.js
var require_mergeScan2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/mergeScan.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var mergeScan_1 = require_mergeScan();
    rxjs_1.Observable.prototype.mergeScan = mergeScan_1.mergeScan;
  }
});

// node_modules/rxjs-compat/operator/min.js
var require_min = __commonJS({
  "node_modules/rxjs-compat/operator/min.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function min(comparer) {
      return operators_1.min(comparer)(this);
    }
    exports.min = min;
  }
});

// node_modules/rxjs-compat/add/operator/min.js
var require_min2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/min.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var min_1 = require_min();
    rxjs_1.Observable.prototype.min = min_1.min;
  }
});

// node_modules/rxjs-compat/operator/multicast.js
var require_multicast = __commonJS({
  "node_modules/rxjs-compat/operator/multicast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function multicast(subjectOrSubjectFactory, selector) {
      return operators_1.multicast(subjectOrSubjectFactory, selector)(this);
    }
    exports.multicast = multicast;
  }
});

// node_modules/rxjs-compat/add/operator/multicast.js
var require_multicast2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/multicast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var multicast_1 = require_multicast();
    rxjs_1.Observable.prototype.multicast = multicast_1.multicast;
  }
});

// node_modules/rxjs-compat/operator/observeOn.js
var require_observeOn = __commonJS({
  "node_modules/rxjs-compat/operator/observeOn.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function observeOn(scheduler, delay) {
      if (delay === void 0) {
        delay = 0;
      }
      return operators_1.observeOn(scheduler, delay)(this);
    }
    exports.observeOn = observeOn;
  }
});

// node_modules/rxjs-compat/add/operator/observeOn.js
var require_observeOn2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/observeOn.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var observeOn_1 = require_observeOn();
    rxjs_1.Observable.prototype.observeOn = observeOn_1.observeOn;
  }
});

// node_modules/rxjs-compat/operator/onErrorResumeNext.js
var require_onErrorResumeNext2 = __commonJS({
  "node_modules/rxjs-compat/operator/onErrorResumeNext.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function onErrorResumeNext() {
      var nextSources = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        nextSources[_i] = arguments[_i];
      }
      return operators_1.onErrorResumeNext.apply(void 0, nextSources)(this);
    }
    exports.onErrorResumeNext = onErrorResumeNext;
  }
});

// node_modules/rxjs-compat/add/operator/onErrorResumeNext.js
var require_onErrorResumeNext3 = __commonJS({
  "node_modules/rxjs-compat/add/operator/onErrorResumeNext.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var onErrorResumeNext_1 = require_onErrorResumeNext2();
    rxjs_1.Observable.prototype.onErrorResumeNext = onErrorResumeNext_1.onErrorResumeNext;
  }
});

// node_modules/rxjs-compat/operator/pairwise.js
var require_pairwise = __commonJS({
  "node_modules/rxjs-compat/operator/pairwise.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function pairwise() {
      return operators_1.pairwise()(this);
    }
    exports.pairwise = pairwise;
  }
});

// node_modules/rxjs-compat/add/operator/pairwise.js
var require_pairwise2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/pairwise.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var pairwise_1 = require_pairwise();
    rxjs_1.Observable.prototype.pairwise = pairwise_1.pairwise;
  }
});

// node_modules/rxjs-compat/operator/partition.js
var require_partition = __commonJS({
  "node_modules/rxjs-compat/operator/partition.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function partition(predicate, thisArg) {
      return operators_1.partition(predicate, thisArg)(this);
    }
    exports.partition = partition;
  }
});

// node_modules/rxjs-compat/add/operator/partition.js
var require_partition2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/partition.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var partition_1 = require_partition();
    rxjs_1.Observable.prototype.partition = partition_1.partition;
  }
});

// node_modules/rxjs-compat/operator/pluck.js
var require_pluck = __commonJS({
  "node_modules/rxjs-compat/operator/pluck.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function pluck() {
      var properties = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        properties[_i] = arguments[_i];
      }
      return operators_1.pluck.apply(void 0, properties)(this);
    }
    exports.pluck = pluck;
  }
});

// node_modules/rxjs-compat/add/operator/pluck.js
var require_pluck2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/pluck.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var pluck_1 = require_pluck();
    rxjs_1.Observable.prototype.pluck = pluck_1.pluck;
  }
});

// node_modules/rxjs-compat/operator/publish.js
var require_publish = __commonJS({
  "node_modules/rxjs-compat/operator/publish.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function publish(selector) {
      return operators_1.publish(selector)(this);
    }
    exports.publish = publish;
  }
});

// node_modules/rxjs-compat/add/operator/publish.js
var require_publish2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/publish.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var publish_1 = require_publish();
    rxjs_1.Observable.prototype.publish = publish_1.publish;
  }
});

// node_modules/rxjs-compat/operator/publishBehavior.js
var require_publishBehavior = __commonJS({
  "node_modules/rxjs-compat/operator/publishBehavior.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function publishBehavior(value) {
      return operators_1.publishBehavior(value)(this);
    }
    exports.publishBehavior = publishBehavior;
  }
});

// node_modules/rxjs-compat/add/operator/publishBehavior.js
var require_publishBehavior2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/publishBehavior.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var publishBehavior_1 = require_publishBehavior();
    rxjs_1.Observable.prototype.publishBehavior = publishBehavior_1.publishBehavior;
  }
});

// node_modules/rxjs-compat/operator/publishReplay.js
var require_publishReplay = __commonJS({
  "node_modules/rxjs-compat/operator/publishReplay.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function publishReplay(bufferSize, windowTime, selectorOrScheduler, scheduler) {
      return operators_1.publishReplay(bufferSize, windowTime, selectorOrScheduler, scheduler)(this);
    }
    exports.publishReplay = publishReplay;
  }
});

// node_modules/rxjs-compat/add/operator/publishReplay.js
var require_publishReplay2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/publishReplay.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var publishReplay_1 = require_publishReplay();
    rxjs_1.Observable.prototype.publishReplay = publishReplay_1.publishReplay;
  }
});

// node_modules/rxjs-compat/operator/publishLast.js
var require_publishLast = __commonJS({
  "node_modules/rxjs-compat/operator/publishLast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function publishLast() {
      return operators_1.publishLast()(this);
    }
    exports.publishLast = publishLast;
  }
});

// node_modules/rxjs-compat/add/operator/publishLast.js
var require_publishLast2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/publishLast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var publishLast_1 = require_publishLast();
    rxjs_1.Observable.prototype.publishLast = publishLast_1.publishLast;
  }
});

// node_modules/rxjs-compat/operator/race.js
var require_race2 = __commonJS({
  "node_modules/rxjs-compat/operator/race.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function race() {
      var observables = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        observables[_i] = arguments[_i];
      }
      return operators_1.race.apply(void 0, observables)(this);
    }
    exports.race = race;
  }
});

// node_modules/rxjs-compat/add/operator/race.js
var require_race3 = __commonJS({
  "node_modules/rxjs-compat/add/operator/race.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var race_1 = require_race2();
    rxjs_1.Observable.prototype.race = race_1.race;
  }
});

// node_modules/rxjs-compat/operator/reduce.js
var require_reduce = __commonJS({
  "node_modules/rxjs-compat/operator/reduce.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function reduce(accumulator, seed) {
      if (arguments.length >= 2) {
        return operators_1.reduce(accumulator, seed)(this);
      }
      return operators_1.reduce(accumulator)(this);
    }
    exports.reduce = reduce;
  }
});

// node_modules/rxjs-compat/add/operator/reduce.js
var require_reduce2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/reduce.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var reduce_1 = require_reduce();
    rxjs_1.Observable.prototype.reduce = reduce_1.reduce;
  }
});

// node_modules/rxjs-compat/operator/repeat.js
var require_repeat = __commonJS({
  "node_modules/rxjs-compat/operator/repeat.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function repeat(count) {
      if (count === void 0) {
        count = -1;
      }
      return operators_1.repeat(count)(this);
    }
    exports.repeat = repeat;
  }
});

// node_modules/rxjs-compat/add/operator/repeat.js
var require_repeat2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/repeat.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var repeat_1 = require_repeat();
    rxjs_1.Observable.prototype.repeat = repeat_1.repeat;
  }
});

// node_modules/rxjs-compat/operator/repeatWhen.js
var require_repeatWhen = __commonJS({
  "node_modules/rxjs-compat/operator/repeatWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function repeatWhen(notifier) {
      return operators_1.repeatWhen(notifier)(this);
    }
    exports.repeatWhen = repeatWhen;
  }
});

// node_modules/rxjs-compat/add/operator/repeatWhen.js
var require_repeatWhen2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/repeatWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var repeatWhen_1 = require_repeatWhen();
    rxjs_1.Observable.prototype.repeatWhen = repeatWhen_1.repeatWhen;
  }
});

// node_modules/rxjs-compat/operator/retry.js
var require_retry = __commonJS({
  "node_modules/rxjs-compat/operator/retry.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function retry(count) {
      if (count === void 0) {
        count = -1;
      }
      return operators_1.retry(count)(this);
    }
    exports.retry = retry;
  }
});

// node_modules/rxjs-compat/add/operator/retry.js
var require_retry2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/retry.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var retry_1 = require_retry();
    rxjs_1.Observable.prototype.retry = retry_1.retry;
  }
});

// node_modules/rxjs-compat/operator/retryWhen.js
var require_retryWhen = __commonJS({
  "node_modules/rxjs-compat/operator/retryWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function retryWhen(notifier) {
      return operators_1.retryWhen(notifier)(this);
    }
    exports.retryWhen = retryWhen;
  }
});

// node_modules/rxjs-compat/add/operator/retryWhen.js
var require_retryWhen2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/retryWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var retryWhen_1 = require_retryWhen();
    rxjs_1.Observable.prototype.retryWhen = retryWhen_1.retryWhen;
  }
});

// node_modules/rxjs-compat/operator/sample.js
var require_sample = __commonJS({
  "node_modules/rxjs-compat/operator/sample.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function sample(notifier) {
      return operators_1.sample(notifier)(this);
    }
    exports.sample = sample;
  }
});

// node_modules/rxjs-compat/add/operator/sample.js
var require_sample2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/sample.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var sample_1 = require_sample();
    rxjs_1.Observable.prototype.sample = sample_1.sample;
  }
});

// node_modules/rxjs-compat/operator/sampleTime.js
var require_sampleTime = __commonJS({
  "node_modules/rxjs-compat/operator/sampleTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function sampleTime(period, scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.sampleTime(period, scheduler)(this);
    }
    exports.sampleTime = sampleTime;
  }
});

// node_modules/rxjs-compat/add/operator/sampleTime.js
var require_sampleTime2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/sampleTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var sampleTime_1 = require_sampleTime();
    rxjs_1.Observable.prototype.sampleTime = sampleTime_1.sampleTime;
  }
});

// node_modules/rxjs-compat/operator/scan.js
var require_scan = __commonJS({
  "node_modules/rxjs-compat/operator/scan.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function scan(accumulator, seed) {
      if (arguments.length >= 2) {
        return operators_1.scan(accumulator, seed)(this);
      }
      return operators_1.scan(accumulator)(this);
    }
    exports.scan = scan;
  }
});

// node_modules/rxjs-compat/add/operator/scan.js
var require_scan2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/scan.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var scan_1 = require_scan();
    rxjs_1.Observable.prototype.scan = scan_1.scan;
  }
});

// node_modules/rxjs-compat/operator/sequenceEqual.js
var require_sequenceEqual = __commonJS({
  "node_modules/rxjs-compat/operator/sequenceEqual.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function sequenceEqual(compareTo, comparor) {
      return operators_1.sequenceEqual(compareTo, comparor)(this);
    }
    exports.sequenceEqual = sequenceEqual;
  }
});

// node_modules/rxjs-compat/add/operator/sequenceEqual.js
var require_sequenceEqual2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/sequenceEqual.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var sequenceEqual_1 = require_sequenceEqual();
    rxjs_1.Observable.prototype.sequenceEqual = sequenceEqual_1.sequenceEqual;
  }
});

// node_modules/rxjs-compat/operator/share.js
var require_share = __commonJS({
  "node_modules/rxjs-compat/operator/share.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function share() {
      return operators_1.share()(this);
    }
    exports.share = share;
  }
});

// node_modules/rxjs-compat/add/operator/share.js
var require_share2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/share.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var share_1 = require_share();
    rxjs_1.Observable.prototype.share = share_1.share;
  }
});

// node_modules/rxjs-compat/operator/shareReplay.js
var require_shareReplay = __commonJS({
  "node_modules/rxjs-compat/operator/shareReplay.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function shareReplay(configOrBufferSize, windowTime, scheduler) {
      if (configOrBufferSize && typeof configOrBufferSize === "object") {
        return operators_1.shareReplay(configOrBufferSize)(this);
      }
      return operators_1.shareReplay(configOrBufferSize, windowTime, scheduler)(this);
    }
    exports.shareReplay = shareReplay;
  }
});

// node_modules/rxjs-compat/add/operator/shareReplay.js
var require_shareReplay2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/shareReplay.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var shareReplay_1 = require_shareReplay();
    rxjs_1.Observable.prototype.shareReplay = shareReplay_1.shareReplay;
  }
});

// node_modules/rxjs-compat/operator/single.js
var require_single = __commonJS({
  "node_modules/rxjs-compat/operator/single.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function single(predicate) {
      return operators_1.single(predicate)(this);
    }
    exports.single = single;
  }
});

// node_modules/rxjs-compat/add/operator/single.js
var require_single2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/single.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var single_1 = require_single();
    rxjs_1.Observable.prototype.single = single_1.single;
  }
});

// node_modules/rxjs-compat/operator/skip.js
var require_skip = __commonJS({
  "node_modules/rxjs-compat/operator/skip.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function skip(count) {
      return operators_1.skip(count)(this);
    }
    exports.skip = skip;
  }
});

// node_modules/rxjs-compat/add/operator/skip.js
var require_skip2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/skip.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var skip_1 = require_skip();
    rxjs_1.Observable.prototype.skip = skip_1.skip;
  }
});

// node_modules/rxjs-compat/operator/skipLast.js
var require_skipLast = __commonJS({
  "node_modules/rxjs-compat/operator/skipLast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function skipLast(count) {
      return operators_1.skipLast(count)(this);
    }
    exports.skipLast = skipLast;
  }
});

// node_modules/rxjs-compat/add/operator/skipLast.js
var require_skipLast2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/skipLast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var skipLast_1 = require_skipLast();
    rxjs_1.Observable.prototype.skipLast = skipLast_1.skipLast;
  }
});

// node_modules/rxjs-compat/operator/skipUntil.js
var require_skipUntil = __commonJS({
  "node_modules/rxjs-compat/operator/skipUntil.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function skipUntil(notifier) {
      return operators_1.skipUntil(notifier)(this);
    }
    exports.skipUntil = skipUntil;
  }
});

// node_modules/rxjs-compat/add/operator/skipUntil.js
var require_skipUntil2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/skipUntil.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var skipUntil_1 = require_skipUntil();
    rxjs_1.Observable.prototype.skipUntil = skipUntil_1.skipUntil;
  }
});

// node_modules/rxjs-compat/operator/skipWhile.js
var require_skipWhile = __commonJS({
  "node_modules/rxjs-compat/operator/skipWhile.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function skipWhile(predicate) {
      return operators_1.skipWhile(predicate)(this);
    }
    exports.skipWhile = skipWhile;
  }
});

// node_modules/rxjs-compat/add/operator/skipWhile.js
var require_skipWhile2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/skipWhile.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var skipWhile_1 = require_skipWhile();
    rxjs_1.Observable.prototype.skipWhile = skipWhile_1.skipWhile;
  }
});

// node_modules/rxjs-compat/operator/startWith.js
var require_startWith = __commonJS({
  "node_modules/rxjs-compat/operator/startWith.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function startWith() {
      var array = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        array[_i] = arguments[_i];
      }
      return operators_1.startWith.apply(void 0, array)(this);
    }
    exports.startWith = startWith;
  }
});

// node_modules/rxjs-compat/add/operator/startWith.js
var require_startWith2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/startWith.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var startWith_1 = require_startWith();
    rxjs_1.Observable.prototype.startWith = startWith_1.startWith;
  }
});

// node_modules/rxjs-compat/operator/subscribeOn.js
var require_subscribeOn = __commonJS({
  "node_modules/rxjs-compat/operator/subscribeOn.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function subscribeOn(scheduler, delay) {
      if (delay === void 0) {
        delay = 0;
      }
      return operators_1.subscribeOn(scheduler, delay)(this);
    }
    exports.subscribeOn = subscribeOn;
  }
});

// node_modules/rxjs-compat/add/operator/subscribeOn.js
var require_subscribeOn2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/subscribeOn.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var subscribeOn_1 = require_subscribeOn();
    rxjs_1.Observable.prototype.subscribeOn = subscribeOn_1.subscribeOn;
  }
});

// node_modules/rxjs-compat/operator/switch.js
var require_switch = __commonJS({
  "node_modules/rxjs-compat/operator/switch.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function _switch() {
      return operators_1.switchAll()(this);
    }
    exports._switch = _switch;
  }
});

// node_modules/rxjs-compat/add/operator/switch.js
var require_switch2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/switch.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var switch_1 = require_switch();
    rxjs_1.Observable.prototype.switch = switch_1._switch;
    rxjs_1.Observable.prototype._switch = switch_1._switch;
  }
});

// node_modules/rxjs-compat/operator/switchMap.js
var require_switchMap = __commonJS({
  "node_modules/rxjs-compat/operator/switchMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function switchMap(project) {
      return operators_1.switchMap(project)(this);
    }
    exports.switchMap = switchMap;
  }
});

// node_modules/rxjs-compat/add/operator/switchMap.js
var require_switchMap2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/switchMap.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var switchMap_1 = require_switchMap();
    rxjs_1.Observable.prototype.switchMap = switchMap_1.switchMap;
  }
});

// node_modules/rxjs-compat/operator/switchMapTo.js
var require_switchMapTo = __commonJS({
  "node_modules/rxjs-compat/operator/switchMapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function switchMapTo(innerObservable) {
      return operators_1.switchMapTo(innerObservable)(this);
    }
    exports.switchMapTo = switchMapTo;
  }
});

// node_modules/rxjs-compat/add/operator/switchMapTo.js
var require_switchMapTo2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/switchMapTo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var switchMapTo_1 = require_switchMapTo();
    rxjs_1.Observable.prototype.switchMapTo = switchMapTo_1.switchMapTo;
  }
});

// node_modules/rxjs-compat/operator/take.js
var require_take = __commonJS({
  "node_modules/rxjs-compat/operator/take.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function take(count) {
      return operators_1.take(count)(this);
    }
    exports.take = take;
  }
});

// node_modules/rxjs-compat/add/operator/take.js
var require_take2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/take.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var take_1 = require_take();
    rxjs_1.Observable.prototype.take = take_1.take;
  }
});

// node_modules/rxjs-compat/operator/takeLast.js
var require_takeLast = __commonJS({
  "node_modules/rxjs-compat/operator/takeLast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function takeLast(count) {
      return operators_1.takeLast(count)(this);
    }
    exports.takeLast = takeLast;
  }
});

// node_modules/rxjs-compat/add/operator/takeLast.js
var require_takeLast2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/takeLast.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var takeLast_1 = require_takeLast();
    rxjs_1.Observable.prototype.takeLast = takeLast_1.takeLast;
  }
});

// node_modules/rxjs-compat/operator/takeUntil.js
var require_takeUntil = __commonJS({
  "node_modules/rxjs-compat/operator/takeUntil.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function takeUntil(notifier) {
      return operators_1.takeUntil(notifier)(this);
    }
    exports.takeUntil = takeUntil;
  }
});

// node_modules/rxjs-compat/add/operator/takeUntil.js
var require_takeUntil2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/takeUntil.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var takeUntil_1 = require_takeUntil();
    rxjs_1.Observable.prototype.takeUntil = takeUntil_1.takeUntil;
  }
});

// node_modules/rxjs-compat/operator/takeWhile.js
var require_takeWhile = __commonJS({
  "node_modules/rxjs-compat/operator/takeWhile.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function takeWhile(predicate) {
      return operators_1.takeWhile(predicate)(this);
    }
    exports.takeWhile = takeWhile;
  }
});

// node_modules/rxjs-compat/add/operator/takeWhile.js
var require_takeWhile2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/takeWhile.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var takeWhile_1 = require_takeWhile();
    rxjs_1.Observable.prototype.takeWhile = takeWhile_1.takeWhile;
  }
});

// node_modules/rxjs-compat/operator/throttle.js
var require_throttle = __commonJS({
  "node_modules/rxjs-compat/operator/throttle.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    var internal_compatibility_1 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    function throttle(durationSelector, config2) {
      if (config2 === void 0) {
        config2 = internal_compatibility_1.defaultThrottleConfig;
      }
      return operators_1.throttle(durationSelector, config2)(this);
    }
    exports.throttle = throttle;
  }
});

// node_modules/rxjs-compat/add/operator/throttle.js
var require_throttle2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/throttle.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var throttle_1 = require_throttle();
    rxjs_1.Observable.prototype.throttle = throttle_1.throttle;
  }
});

// node_modules/rxjs-compat/operator/throttleTime.js
var require_throttleTime = __commonJS({
  "node_modules/rxjs-compat/operator/throttleTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var internal_compatibility_1 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function throttleTime(duration, scheduler, config2) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      if (config2 === void 0) {
        config2 = internal_compatibility_1.defaultThrottleConfig;
      }
      return operators_1.throttleTime(duration, scheduler, config2)(this);
    }
    exports.throttleTime = throttleTime;
  }
});

// node_modules/rxjs-compat/add/operator/throttleTime.js
var require_throttleTime2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/throttleTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var throttleTime_1 = require_throttleTime();
    rxjs_1.Observable.prototype.throttleTime = throttleTime_1.throttleTime;
  }
});

// node_modules/rxjs-compat/operator/timeInterval.js
var require_timeInterval = __commonJS({
  "node_modules/rxjs-compat/operator/timeInterval.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function timeInterval(scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.timeInterval(scheduler)(this);
    }
    exports.timeInterval = timeInterval;
  }
});

// node_modules/rxjs-compat/add/operator/timeInterval.js
var require_timeInterval2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/timeInterval.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var timeInterval_1 = require_timeInterval();
    rxjs_1.Observable.prototype.timeInterval = timeInterval_1.timeInterval;
  }
});

// node_modules/rxjs-compat/operator/timeout.js
var require_timeout = __commonJS({
  "node_modules/rxjs-compat/operator/timeout.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function timeout(due, scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.timeout(due, scheduler)(this);
    }
    exports.timeout = timeout;
  }
});

// node_modules/rxjs-compat/add/operator/timeout.js
var require_timeout2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/timeout.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var timeout_1 = require_timeout();
    rxjs_1.Observable.prototype.timeout = timeout_1.timeout;
  }
});

// node_modules/rxjs-compat/operator/timeoutWith.js
var require_timeoutWith = __commonJS({
  "node_modules/rxjs-compat/operator/timeoutWith.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function timeoutWith(due, withObservable, scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.timeoutWith(due, withObservable, scheduler)(this);
    }
    exports.timeoutWith = timeoutWith;
  }
});

// node_modules/rxjs-compat/add/operator/timeoutWith.js
var require_timeoutWith2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/timeoutWith.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var timeoutWith_1 = require_timeoutWith();
    rxjs_1.Observable.prototype.timeoutWith = timeoutWith_1.timeoutWith;
  }
});

// node_modules/rxjs-compat/operator/timestamp.js
var require_timestamp = __commonJS({
  "node_modules/rxjs-compat/operator/timestamp.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function timestamp(scheduler) {
      if (scheduler === void 0) {
        scheduler = rxjs_1.asyncScheduler;
      }
      return operators_1.timestamp(scheduler)(this);
    }
    exports.timestamp = timestamp;
  }
});

// node_modules/rxjs-compat/add/operator/timestamp.js
var require_timestamp2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/timestamp.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var timestamp_1 = require_timestamp();
    rxjs_1.Observable.prototype.timestamp = timestamp_1.timestamp;
  }
});

// node_modules/rxjs-compat/operator/toArray.js
var require_toArray = __commonJS({
  "node_modules/rxjs-compat/operator/toArray.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function toArray() {
      return operators_1.toArray()(this);
    }
    exports.toArray = toArray;
  }
});

// node_modules/rxjs-compat/add/operator/toArray.js
var require_toArray2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/toArray.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var toArray_1 = require_toArray();
    rxjs_1.Observable.prototype.toArray = toArray_1.toArray;
  }
});

// node_modules/rxjs-compat/add/operator/toPromise.js
var require_toPromise = __commonJS({
  "node_modules/rxjs-compat/add/operator/toPromise.js"() {
  }
});

// node_modules/rxjs-compat/operator/window.js
var require_window = __commonJS({
  "node_modules/rxjs-compat/operator/window.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function window2(windowBoundaries) {
      return operators_1.window(windowBoundaries)(this);
    }
    exports.window = window2;
  }
});

// node_modules/rxjs-compat/add/operator/window.js
var require_window2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/window.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var window_1 = require_window();
    rxjs_1.Observable.prototype.window = window_1.window;
  }
});

// node_modules/rxjs-compat/operator/windowCount.js
var require_windowCount = __commonJS({
  "node_modules/rxjs-compat/operator/windowCount.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function windowCount(windowSize, startWindowEvery) {
      if (startWindowEvery === void 0) {
        startWindowEvery = 0;
      }
      return operators_1.windowCount(windowSize, startWindowEvery)(this);
    }
    exports.windowCount = windowCount;
  }
});

// node_modules/rxjs-compat/add/operator/windowCount.js
var require_windowCount2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/windowCount.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var windowCount_1 = require_windowCount();
    rxjs_1.Observable.prototype.windowCount = windowCount_1.windowCount;
  }
});

// node_modules/rxjs-compat/operator/windowTime.js
var require_windowTime = __commonJS({
  "node_modules/rxjs-compat/operator/windowTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var internal_compatibility_1 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function windowTime(windowTimeSpan) {
      var scheduler = rxjs_1.asyncScheduler;
      var windowCreationInterval = null;
      var maxWindowSize = Number.POSITIVE_INFINITY;
      if (internal_compatibility_1.isScheduler(arguments[3])) {
        scheduler = arguments[3];
      }
      if (internal_compatibility_1.isScheduler(arguments[2])) {
        scheduler = arguments[2];
      } else if (internal_compatibility_1.isNumeric(arguments[2])) {
        maxWindowSize = Number(arguments[2]);
      }
      if (internal_compatibility_1.isScheduler(arguments[1])) {
        scheduler = arguments[1];
      } else if (internal_compatibility_1.isNumeric(arguments[1])) {
        windowCreationInterval = Number(arguments[1]);
      }
      return operators_1.windowTime(windowTimeSpan, windowCreationInterval, maxWindowSize, scheduler)(this);
    }
    exports.windowTime = windowTime;
  }
});

// node_modules/rxjs-compat/add/operator/windowTime.js
var require_windowTime2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/windowTime.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var windowTime_1 = require_windowTime();
    rxjs_1.Observable.prototype.windowTime = windowTime_1.windowTime;
  }
});

// node_modules/rxjs-compat/operator/windowToggle.js
var require_windowToggle = __commonJS({
  "node_modules/rxjs-compat/operator/windowToggle.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function windowToggle(openings, closingSelector) {
      return operators_1.windowToggle(openings, closingSelector)(this);
    }
    exports.windowToggle = windowToggle;
  }
});

// node_modules/rxjs-compat/add/operator/windowToggle.js
var require_windowToggle2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/windowToggle.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var windowToggle_1 = require_windowToggle();
    rxjs_1.Observable.prototype.windowToggle = windowToggle_1.windowToggle;
  }
});

// node_modules/rxjs-compat/operator/windowWhen.js
var require_windowWhen = __commonJS({
  "node_modules/rxjs-compat/operator/windowWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function windowWhen(closingSelector) {
      return operators_1.windowWhen(closingSelector)(this);
    }
    exports.windowWhen = windowWhen;
  }
});

// node_modules/rxjs-compat/add/operator/windowWhen.js
var require_windowWhen2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/windowWhen.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var windowWhen_1 = require_windowWhen();
    rxjs_1.Observable.prototype.windowWhen = windowWhen_1.windowWhen;
  }
});

// node_modules/rxjs-compat/operator/withLatestFrom.js
var require_withLatestFrom = __commonJS({
  "node_modules/rxjs-compat/operator/withLatestFrom.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function withLatestFrom() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return operators_1.withLatestFrom.apply(void 0, args)(this);
    }
    exports.withLatestFrom = withLatestFrom;
  }
});

// node_modules/rxjs-compat/add/operator/withLatestFrom.js
var require_withLatestFrom2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/withLatestFrom.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var withLatestFrom_1 = require_withLatestFrom();
    rxjs_1.Observable.prototype.withLatestFrom = withLatestFrom_1.withLatestFrom;
  }
});

// node_modules/rxjs-compat/operator/zip.js
var require_zip2 = __commonJS({
  "node_modules/rxjs-compat/operator/zip.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    function zipProto() {
      var observables = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        observables[_i] = arguments[_i];
      }
      return this.lift.call(rxjs_1.zip.apply(void 0, [this].concat(observables)));
    }
    exports.zipProto = zipProto;
  }
});

// node_modules/rxjs-compat/add/operator/zip.js
var require_zip3 = __commonJS({
  "node_modules/rxjs-compat/add/operator/zip.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var zip_1 = require_zip2();
    rxjs_1.Observable.prototype.zip = zip_1.zipProto;
  }
});

// node_modules/rxjs-compat/operator/zipAll.js
var require_zipAll = __commonJS({
  "node_modules/rxjs-compat/operator/zipAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var operators_1 = (init_operators(), __toCommonJS(operators_exports));
    function zipAll(project) {
      return operators_1.zipAll(project)(this);
    }
    exports.zipAll = zipAll;
  }
});

// node_modules/rxjs-compat/add/operator/zipAll.js
var require_zipAll2 = __commonJS({
  "node_modules/rxjs-compat/add/operator/zipAll.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    var zipAll_1 = require_zipAll();
    rxjs_1.Observable.prototype.zipAll = zipAll_1.zipAll;
  }
});

// node_modules/rxjs/_esm5/internal/testing/SubscriptionLog.js
var SubscriptionLog;
var init_SubscriptionLog = __esm({
  "node_modules/rxjs/_esm5/internal/testing/SubscriptionLog.js"() {
    SubscriptionLog = /* @__PURE__ */ function() {
      function SubscriptionLog2(subscribedFrame, unsubscribedFrame) {
        if (unsubscribedFrame === void 0) {
          unsubscribedFrame = Number.POSITIVE_INFINITY;
        }
        this.subscribedFrame = subscribedFrame;
        this.unsubscribedFrame = unsubscribedFrame;
      }
      return SubscriptionLog2;
    }();
  }
});

// node_modules/rxjs/_esm5/internal/testing/SubscriptionLoggable.js
var SubscriptionLoggable;
var init_SubscriptionLoggable = __esm({
  "node_modules/rxjs/_esm5/internal/testing/SubscriptionLoggable.js"() {
    init_SubscriptionLog();
    SubscriptionLoggable = function() {
      function SubscriptionLoggable2() {
        this.subscriptions = [];
      }
      SubscriptionLoggable2.prototype.logSubscribedFrame = function() {
        this.subscriptions.push(new SubscriptionLog(this.scheduler.now()));
        return this.subscriptions.length - 1;
      };
      SubscriptionLoggable2.prototype.logUnsubscribedFrame = function(index) {
        var subscriptionLogs = this.subscriptions;
        var oldSubscriptionLog = subscriptionLogs[index];
        subscriptionLogs[index] = new SubscriptionLog(oldSubscriptionLog.subscribedFrame, this.scheduler.now());
      };
      return SubscriptionLoggable2;
    }();
  }
});

// node_modules/rxjs/_esm5/internal/testing/ColdObservable.js
var ColdObservable;
var init_ColdObservable = __esm({
  "node_modules/rxjs/_esm5/internal/testing/ColdObservable.js"() {
    init_tslib_es6();
    init_Observable();
    init_Subscription();
    init_SubscriptionLoggable();
    init_applyMixins();
    ColdObservable = function(_super) {
      __extends(ColdObservable2, _super);
      function ColdObservable2(messages, scheduler) {
        var _this = _super.call(this, function(subscriber) {
          var observable2 = this;
          var index = observable2.logSubscribedFrame();
          var subscription = new Subscription();
          subscription.add(new Subscription(function() {
            observable2.logUnsubscribedFrame(index);
          }));
          observable2.scheduleMessages(subscriber);
          return subscription;
        }) || this;
        _this.messages = messages;
        _this.subscriptions = [];
        _this.scheduler = scheduler;
        return _this;
      }
      ColdObservable2.prototype.scheduleMessages = function(subscriber) {
        var messagesLength = this.messages.length;
        for (var i = 0; i < messagesLength; i++) {
          var message = this.messages[i];
          subscriber.add(this.scheduler.schedule(function(_a) {
            var message2 = _a.message, subscriber2 = _a.subscriber;
            message2.notification.observe(subscriber2);
          }, message.frame, {
            message,
            subscriber
          }));
        }
      };
      return ColdObservable2;
    }(Observable);
    applyMixins(ColdObservable, [SubscriptionLoggable]);
  }
});

// node_modules/rxjs/_esm5/internal/testing/HotObservable.js
var HotObservable;
var init_HotObservable = __esm({
  "node_modules/rxjs/_esm5/internal/testing/HotObservable.js"() {
    init_tslib_es6();
    init_Subject();
    init_Subscription();
    init_SubscriptionLoggable();
    init_applyMixins();
    HotObservable = function(_super) {
      __extends(HotObservable2, _super);
      function HotObservable2(messages, scheduler) {
        var _this = _super.call(this) || this;
        _this.messages = messages;
        _this.subscriptions = [];
        _this.scheduler = scheduler;
        return _this;
      }
      HotObservable2.prototype._subscribe = function(subscriber) {
        var subject = this;
        var index = subject.logSubscribedFrame();
        var subscription = new Subscription();
        subscription.add(new Subscription(function() {
          subject.logUnsubscribedFrame(index);
        }));
        subscription.add(_super.prototype._subscribe.call(this, subscriber));
        return subscription;
      };
      HotObservable2.prototype.setup = function() {
        var subject = this;
        var messagesLength = subject.messages.length;
        for (var i = 0; i < messagesLength; i++) {
          (function() {
            var message = subject.messages[i];
            subject.scheduler.schedule(function() {
              message.notification.observe(subject);
            }, message.frame);
          })();
        }
      };
      return HotObservable2;
    }(Subject);
    applyMixins(HotObservable, [SubscriptionLoggable]);
  }
});

// node_modules/rxjs/_esm5/internal/testing/TestScheduler.js
var defaultMaxFrame, TestScheduler;
var init_TestScheduler = __esm({
  "node_modules/rxjs/_esm5/internal/testing/TestScheduler.js"() {
    init_tslib_es6();
    init_Observable();
    init_Notification();
    init_ColdObservable();
    init_HotObservable();
    init_SubscriptionLog();
    init_VirtualTimeScheduler();
    init_AsyncScheduler();
    defaultMaxFrame = 750;
    TestScheduler = function(_super) {
      __extends(TestScheduler2, _super);
      function TestScheduler2(assertDeepEqual) {
        var _this = _super.call(this, VirtualAction, defaultMaxFrame) || this;
        _this.assertDeepEqual = assertDeepEqual;
        _this.hotObservables = [];
        _this.coldObservables = [];
        _this.flushTests = [];
        _this.runMode = false;
        return _this;
      }
      TestScheduler2.prototype.createTime = function(marbles) {
        var indexOf = marbles.indexOf("|");
        if (indexOf === -1) {
          throw new Error('marble diagram for time should have a completion marker "|"');
        }
        return indexOf * TestScheduler2.frameTimeFactor;
      };
      TestScheduler2.prototype.createColdObservable = function(marbles, values, error) {
        if (marbles.indexOf("^") !== -1) {
          throw new Error('cold observable cannot have subscription offset "^"');
        }
        if (marbles.indexOf("!") !== -1) {
          throw new Error('cold observable cannot have unsubscription marker "!"');
        }
        var messages = TestScheduler2.parseMarbles(marbles, values, error, void 0, this.runMode);
        var cold = new ColdObservable(messages, this);
        this.coldObservables.push(cold);
        return cold;
      };
      TestScheduler2.prototype.createHotObservable = function(marbles, values, error) {
        if (marbles.indexOf("!") !== -1) {
          throw new Error('hot observable cannot have unsubscription marker "!"');
        }
        var messages = TestScheduler2.parseMarbles(marbles, values, error, void 0, this.runMode);
        var subject = new HotObservable(messages, this);
        this.hotObservables.push(subject);
        return subject;
      };
      TestScheduler2.prototype.materializeInnerObservable = function(observable2, outerFrame) {
        var _this = this;
        var messages = [];
        observable2.subscribe(function(value) {
          messages.push({
            frame: _this.frame - outerFrame,
            notification: Notification.createNext(value)
          });
        }, function(err) {
          messages.push({
            frame: _this.frame - outerFrame,
            notification: Notification.createError(err)
          });
        }, function() {
          messages.push({
            frame: _this.frame - outerFrame,
            notification: Notification.createComplete()
          });
        });
        return messages;
      };
      TestScheduler2.prototype.expectObservable = function(observable2, subscriptionMarbles) {
        var _this = this;
        if (subscriptionMarbles === void 0) {
          subscriptionMarbles = null;
        }
        var actual = [];
        var flushTest = {
          actual,
          ready: false
        };
        var subscriptionParsed = TestScheduler2.parseMarblesAsSubscriptions(subscriptionMarbles, this.runMode);
        var subscriptionFrame = subscriptionParsed.subscribedFrame === Number.POSITIVE_INFINITY ? 0 : subscriptionParsed.subscribedFrame;
        var unsubscriptionFrame = subscriptionParsed.unsubscribedFrame;
        var subscription;
        this.schedule(function() {
          subscription = observable2.subscribe(function(x) {
            var value = x;
            if (x instanceof Observable) {
              value = _this.materializeInnerObservable(value, _this.frame);
            }
            actual.push({
              frame: _this.frame,
              notification: Notification.createNext(value)
            });
          }, function(err) {
            actual.push({
              frame: _this.frame,
              notification: Notification.createError(err)
            });
          }, function() {
            actual.push({
              frame: _this.frame,
              notification: Notification.createComplete()
            });
          });
        }, subscriptionFrame);
        if (unsubscriptionFrame !== Number.POSITIVE_INFINITY) {
          this.schedule(function() {
            return subscription.unsubscribe();
          }, unsubscriptionFrame);
        }
        this.flushTests.push(flushTest);
        var runMode = this.runMode;
        return {
          toBe: function(marbles, values, errorValue) {
            flushTest.ready = true;
            flushTest.expected = TestScheduler2.parseMarbles(marbles, values, errorValue, true, runMode);
          }
        };
      };
      TestScheduler2.prototype.expectSubscriptions = function(actualSubscriptionLogs) {
        var flushTest = {
          actual: actualSubscriptionLogs,
          ready: false
        };
        this.flushTests.push(flushTest);
        var runMode = this.runMode;
        return {
          toBe: function(marbles) {
            var marblesArray = typeof marbles === "string" ? [marbles] : marbles;
            flushTest.ready = true;
            flushTest.expected = marblesArray.map(function(marbles2) {
              return TestScheduler2.parseMarblesAsSubscriptions(marbles2, runMode);
            });
          }
        };
      };
      TestScheduler2.prototype.flush = function() {
        var _this = this;
        var hotObservables = this.hotObservables;
        while (hotObservables.length > 0) {
          hotObservables.shift().setup();
        }
        _super.prototype.flush.call(this);
        this.flushTests = this.flushTests.filter(function(test) {
          if (test.ready) {
            _this.assertDeepEqual(test.actual, test.expected);
            return false;
          }
          return true;
        });
      };
      TestScheduler2.parseMarblesAsSubscriptions = function(marbles, runMode) {
        var _this = this;
        if (runMode === void 0) {
          runMode = false;
        }
        if (typeof marbles !== "string") {
          return new SubscriptionLog(Number.POSITIVE_INFINITY);
        }
        var len = marbles.length;
        var groupStart = -1;
        var subscriptionFrame = Number.POSITIVE_INFINITY;
        var unsubscriptionFrame = Number.POSITIVE_INFINITY;
        var frame = 0;
        var _loop_1 = function(i2) {
          var nextFrame = frame;
          var advanceFrameBy = function(count) {
            nextFrame += count * _this.frameTimeFactor;
          };
          var c = marbles[i2];
          switch (c) {
            case " ":
              if (!runMode) {
                advanceFrameBy(1);
              }
              break;
            case "-":
              advanceFrameBy(1);
              break;
            case "(":
              groupStart = frame;
              advanceFrameBy(1);
              break;
            case ")":
              groupStart = -1;
              advanceFrameBy(1);
              break;
            case "^":
              if (subscriptionFrame !== Number.POSITIVE_INFINITY) {
                throw new Error("found a second subscription point '^' in a subscription marble diagram. There can only be one.");
              }
              subscriptionFrame = groupStart > -1 ? groupStart : frame;
              advanceFrameBy(1);
              break;
            case "!":
              if (unsubscriptionFrame !== Number.POSITIVE_INFINITY) {
                throw new Error("found a second subscription point '^' in a subscription marble diagram. There can only be one.");
              }
              unsubscriptionFrame = groupStart > -1 ? groupStart : frame;
              break;
            default:
              if (runMode && c.match(/^[0-9]$/)) {
                if (i2 === 0 || marbles[i2 - 1] === " ") {
                  var buffer = marbles.slice(i2);
                  var match = buffer.match(/^([0-9]+(?:\.[0-9]+)?)(ms|s|m) /);
                  if (match) {
                    i2 += match[0].length - 1;
                    var duration = parseFloat(match[1]);
                    var unit = match[2];
                    var durationInMs = void 0;
                    switch (unit) {
                      case "ms":
                        durationInMs = duration;
                        break;
                      case "s":
                        durationInMs = duration * 1e3;
                        break;
                      case "m":
                        durationInMs = duration * 1e3 * 60;
                        break;
                      default:
                        break;
                    }
                    advanceFrameBy(durationInMs / this_1.frameTimeFactor);
                    break;
                  }
                }
              }
              throw new Error("there can only be '^' and '!' markers in a subscription marble diagram. Found instead '" + c + "'.");
          }
          frame = nextFrame;
          out_i_1 = i2;
        };
        var this_1 = this, out_i_1;
        for (var i = 0; i < len; i++) {
          _loop_1(i);
          i = out_i_1;
        }
        if (unsubscriptionFrame < 0) {
          return new SubscriptionLog(subscriptionFrame);
        } else {
          return new SubscriptionLog(subscriptionFrame, unsubscriptionFrame);
        }
      };
      TestScheduler2.parseMarbles = function(marbles, values, errorValue, materializeInnerObservables, runMode) {
        var _this = this;
        if (materializeInnerObservables === void 0) {
          materializeInnerObservables = false;
        }
        if (runMode === void 0) {
          runMode = false;
        }
        if (marbles.indexOf("!") !== -1) {
          throw new Error('conventional marble diagrams cannot have the unsubscription marker "!"');
        }
        var len = marbles.length;
        var testMessages = [];
        var subIndex = runMode ? marbles.replace(/^[ ]+/, "").indexOf("^") : marbles.indexOf("^");
        var frame = subIndex === -1 ? 0 : subIndex * -this.frameTimeFactor;
        var getValue = typeof values !== "object" ? function(x) {
          return x;
        } : function(x) {
          if (materializeInnerObservables && values[x] instanceof ColdObservable) {
            return values[x].messages;
          }
          return values[x];
        };
        var groupStart = -1;
        var _loop_2 = function(i2) {
          var nextFrame = frame;
          var advanceFrameBy = function(count) {
            nextFrame += count * _this.frameTimeFactor;
          };
          var notification = void 0;
          var c = marbles[i2];
          switch (c) {
            case " ":
              if (!runMode) {
                advanceFrameBy(1);
              }
              break;
            case "-":
              advanceFrameBy(1);
              break;
            case "(":
              groupStart = frame;
              advanceFrameBy(1);
              break;
            case ")":
              groupStart = -1;
              advanceFrameBy(1);
              break;
            case "|":
              notification = Notification.createComplete();
              advanceFrameBy(1);
              break;
            case "^":
              advanceFrameBy(1);
              break;
            case "#":
              notification = Notification.createError(errorValue || "error");
              advanceFrameBy(1);
              break;
            default:
              if (runMode && c.match(/^[0-9]$/)) {
                if (i2 === 0 || marbles[i2 - 1] === " ") {
                  var buffer = marbles.slice(i2);
                  var match = buffer.match(/^([0-9]+(?:\.[0-9]+)?)(ms|s|m) /);
                  if (match) {
                    i2 += match[0].length - 1;
                    var duration = parseFloat(match[1]);
                    var unit = match[2];
                    var durationInMs = void 0;
                    switch (unit) {
                      case "ms":
                        durationInMs = duration;
                        break;
                      case "s":
                        durationInMs = duration * 1e3;
                        break;
                      case "m":
                        durationInMs = duration * 1e3 * 60;
                        break;
                      default:
                        break;
                    }
                    advanceFrameBy(durationInMs / this_2.frameTimeFactor);
                    break;
                  }
                }
              }
              notification = Notification.createNext(getValue(c));
              advanceFrameBy(1);
              break;
          }
          if (notification) {
            testMessages.push({
              frame: groupStart > -1 ? groupStart : frame,
              notification
            });
          }
          frame = nextFrame;
          out_i_2 = i2;
        };
        var this_2 = this, out_i_2;
        for (var i = 0; i < len; i++) {
          _loop_2(i);
          i = out_i_2;
        }
        return testMessages;
      };
      TestScheduler2.prototype.run = function(callback) {
        var prevFrameTimeFactor = TestScheduler2.frameTimeFactor;
        var prevMaxFrames = this.maxFrames;
        TestScheduler2.frameTimeFactor = 1;
        this.maxFrames = Number.POSITIVE_INFINITY;
        this.runMode = true;
        AsyncScheduler.delegate = this;
        var helpers = {
          cold: this.createColdObservable.bind(this),
          hot: this.createHotObservable.bind(this),
          flush: this.flush.bind(this),
          expectObservable: this.expectObservable.bind(this),
          expectSubscriptions: this.expectSubscriptions.bind(this)
        };
        try {
          var ret = callback(helpers);
          this.flush();
          return ret;
        } finally {
          TestScheduler2.frameTimeFactor = prevFrameTimeFactor;
          this.maxFrames = prevMaxFrames;
          this.runMode = false;
          AsyncScheduler.delegate = void 0;
        }
      };
      return TestScheduler2;
    }(VirtualTimeScheduler);
  }
});

// node_modules/rxjs/_esm5/testing/index.js
var testing_exports = {};
__export(testing_exports, {
  TestScheduler: () => TestScheduler
});
var init_testing = __esm({
  "node_modules/rxjs/_esm5/testing/index.js"() {
    init_TestScheduler();
  }
});

// node_modules/rxjs-compat/Rx.js
var require_Rx = __commonJS({
  "node_modules/rxjs-compat/Rx.js"(exports) {
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var rxjs_1 = (init_esm5(), __toCommonJS(esm5_exports));
    exports.Observable = rxjs_1.Observable;
    exports.Subject = rxjs_1.Subject;
    var internal_compatibility_1 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    exports.AnonymousSubject = internal_compatibility_1.AnonymousSubject;
    var internal_compatibility_2 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    exports.config = internal_compatibility_2.config;
    require_bindCallback();
    require_bindNodeCallback();
    require_combineLatest();
    require_concat();
    require_defer();
    require_empty();
    require_forkJoin();
    require_from();
    require_fromEvent();
    require_fromEventPattern();
    require_fromPromise();
    require_generate();
    require_if();
    require_interval();
    require_merge();
    require_race();
    require_never();
    require_of();
    require_onErrorResumeNext();
    require_pairs();
    require_range();
    require_using();
    require_throw();
    require_timer();
    require_zip();
    require_ajax();
    require_webSocket();
    require_buffer2();
    require_bufferCount2();
    require_bufferTime2();
    require_bufferToggle2();
    require_bufferWhen2();
    require_catch2();
    require_combineAll2();
    require_combineLatest3();
    require_concat3();
    require_concatAll2();
    require_concatMap2();
    require_concatMapTo2();
    require_count2();
    require_dematerialize2();
    require_debounce2();
    require_debounceTime2();
    require_defaultIfEmpty2();
    require_delay2();
    require_delayWhen2();
    require_distinct2();
    require_distinctUntilChanged2();
    require_distinctUntilKeyChanged2();
    require_do2();
    require_exhaust2();
    require_exhaustMap2();
    require_expand2();
    require_elementAt2();
    require_filter2();
    require_finally2();
    require_find2();
    require_findIndex2();
    require_first2();
    require_groupBy2();
    require_ignoreElements2();
    require_isEmpty2();
    require_audit2();
    require_auditTime2();
    require_last2();
    require_let2();
    require_every2();
    require_map2();
    require_mapTo2();
    require_materialize2();
    require_max2();
    require_merge3();
    require_mergeAll2();
    require_mergeMap2();
    require_mergeMapTo2();
    require_mergeScan2();
    require_min2();
    require_multicast2();
    require_observeOn2();
    require_onErrorResumeNext3();
    require_pairwise2();
    require_partition2();
    require_pluck2();
    require_publish2();
    require_publishBehavior2();
    require_publishReplay2();
    require_publishLast2();
    require_race3();
    require_reduce2();
    require_repeat2();
    require_repeatWhen2();
    require_retry2();
    require_retryWhen2();
    require_sample2();
    require_sampleTime2();
    require_scan2();
    require_sequenceEqual2();
    require_share2();
    require_shareReplay2();
    require_single2();
    require_skip2();
    require_skipLast2();
    require_skipUntil2();
    require_skipWhile2();
    require_startWith2();
    require_subscribeOn2();
    require_switch2();
    require_switchMap2();
    require_switchMapTo2();
    require_take2();
    require_takeLast2();
    require_takeUntil2();
    require_takeWhile2();
    require_throttle2();
    require_throttleTime2();
    require_timeInterval2();
    require_timeout2();
    require_timeoutWith2();
    require_timestamp2();
    require_toArray2();
    require_toPromise();
    require_window2();
    require_windowCount2();
    require_windowTime2();
    require_windowToggle2();
    require_windowWhen2();
    require_withLatestFrom2();
    require_zip3();
    require_zipAll2();
    var rxjs_2 = (init_esm5(), __toCommonJS(esm5_exports));
    exports.Subscription = rxjs_2.Subscription;
    exports.ReplaySubject = rxjs_2.ReplaySubject;
    exports.BehaviorSubject = rxjs_2.BehaviorSubject;
    exports.Notification = rxjs_2.Notification;
    exports.EmptyError = rxjs_2.EmptyError;
    exports.ArgumentOutOfRangeError = rxjs_2.ArgumentOutOfRangeError;
    exports.ObjectUnsubscribedError = rxjs_2.ObjectUnsubscribedError;
    exports.UnsubscriptionError = rxjs_2.UnsubscriptionError;
    exports.pipe = rxjs_2.pipe;
    var testing_1 = (init_testing(), __toCommonJS(testing_exports));
    exports.TestScheduler = testing_1.TestScheduler;
    var rxjs_3 = (init_esm5(), __toCommonJS(esm5_exports));
    exports.Subscriber = rxjs_3.Subscriber;
    exports.AsyncSubject = rxjs_3.AsyncSubject;
    exports.ConnectableObservable = rxjs_3.ConnectableObservable;
    exports.TimeoutError = rxjs_3.TimeoutError;
    exports.VirtualTimeScheduler = rxjs_3.VirtualTimeScheduler;
    var ajax_1 = (init_ajax2(), __toCommonJS(ajax_exports));
    exports.AjaxResponse = ajax_1.AjaxResponse;
    exports.AjaxError = ajax_1.AjaxError;
    exports.AjaxTimeoutError = ajax_1.AjaxTimeoutError;
    var rxjs_4 = (init_esm5(), __toCommonJS(esm5_exports));
    var internal_compatibility_3 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    var internal_compatibility_4 = (init_internal_compatibility(), __toCommonJS(internal_compatibility_exports));
    exports.TimeInterval = internal_compatibility_4.TimeInterval;
    exports.Timestamp = internal_compatibility_4.Timestamp;
    var _operators = (init_operators(), __toCommonJS(operators_exports));
    exports.operators = _operators;
    var Scheduler2 = {
      asap: rxjs_4.asapScheduler,
      queue: rxjs_4.queueScheduler,
      animationFrame: rxjs_4.animationFrameScheduler,
      async: rxjs_4.asyncScheduler
    };
    exports.Scheduler = Scheduler2;
    var Symbol = {
      rxSubscriber: internal_compatibility_3.rxSubscriber,
      observable: internal_compatibility_3.observable,
      iterator: internal_compatibility_3.iterator
    };
    exports.Symbol = Symbol;
  }
});
export default require_Rx();
//# sourceMappingURL=rxjs-compat.js.map

import { Component } from '@angular/core';

@Component({
  selector: 'app-parallax',
  imports: [],
  templateUrl: './parallax.component.html',
  styleUrl: './parallax.component.css'
})
export class ParallaxComponent {

}

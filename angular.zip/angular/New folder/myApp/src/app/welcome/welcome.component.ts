import { Component, OnInit } from '@angular/core';
import { WelcomeService } from '../service/welcome.service';

@Component({
  selector: 'app-welcome',
  imports: [],
  templateUrl: './welcome.component.html',
  styleUrl: './welcome.component.css',
})
export class WelcomeComponent implements OnInit {
  constructor(private welcomeService: WelcomeService) {}

  ngOnInit(): void {
    this.welcomeService.greeting();
  }
}

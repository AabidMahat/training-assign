import { Injectable } from '@angular/core';
import { CartItem } from '../shared/cart.modal';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  cartItems: CartItem[] = [];

  addCartItem(cartData: CartItem): void {
    this.cartItems.push(cartData);
  }

  allCartItem(): CartItem[] {
    return this.cartItems;
  }

  getTotal(): number {
    return this.cartItems.reduce((acc, curr) => (acc = acc + curr.price), 0);
  }

  removeCartItem(cartItem: string): void {
    this.cartItems.forEach((item) => {
      if (item.id === cartItem) {
        this.cartItems.pop();
      }
    });
  }
}

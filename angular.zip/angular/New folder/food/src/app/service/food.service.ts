import { Injectable } from '@angular/core';
import { FoodItem } from '../shared/food.modal';

@Injectable({
  providedIn: 'root',
})
export class FoodService {
  foodItems: FoodItem[] = [
    {
      id: 'F0001',
      name: 'Pizza',
      description: 'Cheesy and delicious',
      price: 299,
    },
    {
      id: 'F0002',
      name: 'Biryani',
      description: 'Spicy rice with meat',
      price: 399,
    },
    {
      id: 'F0003',
      name: 'Burger',
      description: 'Juicy grilled beef patty',
      price: 199,
    },
    { id: 'F0004', name: 'Pasta', description: 'Rich and creamy', price: 249 },
    { id: 'F0005', name: 'Sushi', description: 'Fresh and tasty', price: 499 },
    {
      id: 'F0006',
      name: 'Ice Cream',
      description: 'Cold and sweet',
      price: 150,
    },
    {
      id: 'F0007',
      name: 'Salad',
      description: 'Healthy and fresh',
      price: 129,
    },
    {
      id: 'F0008',
      name: 'Tacos',
      description: 'Crunchy and tasty',
      price: 179,
    },
    { id: 'F0009', name: 'Steak', description: 'Tender and juicy', price: 699 },
    {
      id: 'F0010',
      name: 'Sandwich',
      description: 'Light and fulfilling',
      price: 89,
    },
  ];

  allFoodItems(): FoodItem[] {
    return this.foodItems;
  }

  addFoodItem(food: FoodItem): void {
    this.foodItems.push(food);
  }

  getFoodItem(foodItemId: string): FoodItem {
    return this.foodItems.find((item) => item.id === foodItemId)!;
  }

  removeFoodItem(fooItemId: string): void {
    this.foodItems.filter((item) => item.id === fooItemId);
  }
}

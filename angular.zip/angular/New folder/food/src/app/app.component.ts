import { Component, inject } from '@angular/core';

import { FoodComponent } from './food/food.component';
import { CartComponent } from './cart/cart.component';
import { FoodItem } from './shared/food.modal';
import { FoodService } from './service/food.service';
import { CartService } from './service/cart.service';

@Component({
  selector: 'app-root',
  imports: [FoodComponent, CartComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  constructor(public foodService: FoodService) {}
  cartService = inject(CartService);

  totalCartAmount: number = 0;

  onSelectFoodItem(foodId: string) {
    const foodItem: FoodItem = this.foodService.getFoodItem(foodId);

    this.cartService.addCartItem(foodItem);
    console.log(this.cartService.allCartItem());
  }
}

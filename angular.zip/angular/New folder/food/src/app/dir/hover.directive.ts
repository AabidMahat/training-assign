import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[app-dir]',
})
export class HoverOn {
  constructor(private el: ElementRef) {}
  @HostListener('mouseover') onMouseOver() {
    this.el.nativeElement.style.backgroundColor = 'red';
  }
}

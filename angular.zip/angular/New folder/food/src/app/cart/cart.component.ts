import {
  ChangeDetectorRef,
  Component,
  computed,
  inject,
  Input,
  NgModule,
  OnInit,
  Signal,
} from '@angular/core';
import { CartService } from '../service/cart.service';
import { CartItem } from '../shared/cart.modal';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cart',
  imports: [FormsModule],

  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css',
})
export class CartComponent {
  private cartService = inject(CartService);

  cartItem: Signal<CartItem[]> = computed(() => this.cartService.allCartItem());
  totalPrice = computed(() => this.cartService.getTotal());

  onCartRemove(cartItemId: string) {
    this.cartService.removeCartItem(cartItemId);
  }
}

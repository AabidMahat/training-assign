import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { FoodService } from '../service/food.service';
import { HoverOn } from '../dir/hover.directive';

@Component({
  selector: 'app-food',
  imports: [HoverOn],

  templateUrl: './food.component.html',
  styleUrl: './food.component.css',
})
export class FoodComponent {
  @Output() select = new EventEmitter();

  foodService = inject(FoodService);

  foodItems = this.foodService.allFoodItems();

  onSelectFoodItem(foodId: string) {
    this.select.emit(foodId);
  }
}

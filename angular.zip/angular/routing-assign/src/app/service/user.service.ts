import { Injectable } from '@angular/core';

import { User } from './modal/user.modal';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  users: User[] = [
    { id: 1, name: 'Alice', description: 'Software developer and cat lover' },
    {
      id: 2,
      name: 'Bob',
      description: 'Graphic designer with a knack for creativity',
    },
    {
      id: 3,
      name: 'Charlie',
      description: 'Project manager with excellent communication skills',
    },
    {
      id: 4,
      name: 'Daisy',
      description: 'DevOps engineer who loves automation',
    },
    {
      id: 5,
      name: 'Evan',
      description: 'Frontend developer with a passion for UX design',
    },
    {
      id: 6,
      name: 'Fiona',
      description: 'Data scientist with a love for numbers',
    },
    {
      id: 7,
      name: 'George',
      description: 'Backend developer and coffee enthusiast',
    },
    {
      id: 8,
      name: 'Hannah',
      description: 'Cybersecurity expert with a sharp mind',
    },
    {
      id: 9,
      name: 'Ian',
      description: 'AI researcher exploring the future of technology',
    },
    {
      id: 10,
      name: 'Jasmine',
      description:
        'Technical writer with a flair for explaining complex concepts',
    },
  ];

  getUserData(userId: number) {
    return this.users.find((user) => user.id === +userId);
  }
}

import { Component, Input, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../service/modal/user.modal';

@Component({
  selector: 'app-profile',
  standalone: false,

  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css',
})
export class ProfileComponent implements OnInit {
  constructor(private userService: UserService) {}

  @Input({ required: true }) userId!: number;
  userData!: User;

  demo!: string;

  ngOnInit(): void {
    console.log(this.userId);

    this.userData = this.userService.getUserData(this.userId)!;

    localStorage.setItem(
      'loggedIn',
      JSON.stringify({
        isLoggedIn: true,
      })
    );

    JSON.parse(localStorage.getItem('loggedIn')!);
  }
}

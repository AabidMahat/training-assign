import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  logInUser(): void {
    localStorage.setItem(
      'loggedIn',
      JSON.stringify({ isLoggedIn: true, role: 'user' })
    );
  }

  authUser(): boolean {
    if (localStorage.getItem('loggedIn')) {
      return true;
    }
    return false;
  }

  authUserByRole(): boolean {
    if (localStorage.getItem('role')) {
      const role = localStorage.getItem('role') === 'admin' ? 'admin' : 'user';

      if (role === 'admin') {
        return true;
      }
      return false;
    }
    return false;
  }
}

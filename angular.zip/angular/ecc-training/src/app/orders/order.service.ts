import { Injectable } from '@angular/core';
import { Order } from './order.model';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private orders: Order[] = [];

  addOrder(order: Order) {
    this.orders.push(order);
  }

  removeOrder(orderId: number) {
    const orderIndex = this.orders.findIndex((order) => order.id === orderId);

    this.orders.splice(orderIndex, 1);
  }

  calculateTotalPrice(): number {
    return this.orders.reduce((acc, curr) => (acc = acc + curr.price), 0);
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-order-list',
  standalone: false,
  
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.scss'
})
export class OrderListComponent {

}

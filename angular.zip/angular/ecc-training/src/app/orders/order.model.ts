export interface Order {
  id: number;
  name: string;
  price: number;
  category: string;
}

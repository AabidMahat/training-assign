import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customPipe',
  standalone: false,
})
export class CustomPipePipe implements PipeTransform {
  transform(data: string): string {
    return data.slice(-4).padStart(16, '*');
  }
}

export enum Role {
  Admin = 'admin',
  Manager = 'manager',
  Customer = 'customer',
}

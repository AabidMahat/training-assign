import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Role } from './role.enum';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private router: Router) {}

  logIn(): void {
    localStorage.setItem(
      'isLoggedIn',
      JSON.stringify({
        loggedIn: true,
        role: Role.Customer,
      })
    );

    this.router.navigate(['/']);
  }

  isUserAuthenticated(roles: Role[]): boolean {
    const data = JSON.parse(localStorage.getItem('isLoggedIn')!);

    if (!data['loggedIn']) {
      alert('hhhhhhhhhhhhh');
      this.router.navigate(['/']);

      return false;
    }

    if (!roles.includes(data['role'])) {
      alert('hhhhhhhhhhhhh');

      return false;
    }

    return true;
  }
}

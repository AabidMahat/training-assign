import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ProfileComponent } from './profile/profile.component';
import { CustomerGuard } from '../auth/guard/customer.guard';

const route: Routes = [
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'registration',
    component: RegistrationComponent,
    canDeactivate: [CustomerGuard],
  },
  {
    path: 'profile',
    component: ProfileComponent,
    canActivate: [CustomerGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(route)],
  exports: [RouterModule],
})
export class UserRoutingModule {}

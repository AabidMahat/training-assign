import { Component } from '@angular/core';
import { canComponentDeactivate } from '../../auth/guard/customer.guard';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-registration',
  standalone: false,

  templateUrl: './registration.component.html',
  styleUrl: './registration.component.scss',
})
export class RegistrationComponent implements canComponentDeactivate {
  allowEdit = false;
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    console.log('Func called');

    return confirm('Do you waqnt to continue');
  }
}

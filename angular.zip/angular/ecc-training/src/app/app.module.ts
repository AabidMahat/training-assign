import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NotFoundComponent } from './pages/not-found/not-found.component';
import { HomeComponent } from './home/home.component';
import { OrderRoutingModule } from './orders/order-routing.module';
import { UserRoutingModule } from './user/user-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductRoutingModule } from './products/product-routing.module';
import { DecimalPipe } from '@angular/common';
import { CustomPipePipe } from './custom-pipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,
    HomeComponent,
    CustomPipePipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    OrderRoutingModule,
    ProductRoutingModule,
    UserRoutingModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}

import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product.model';
import { OrderService } from '../../orders/order.service';

@Component({
  selector: 'app-product-list',
  standalone: false,

  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.scss',
})
export class ProductListComponent implements OnInit {
  constructor(
    private productService: ProductService,
    private orderService: OrderService
  ) {}

  products: Product[] = [];

  ngOnInit(): void {
    this.products = this.productService.getAllProducts();
  }

  deleteProduct(productId: number) {
    this.productService.deleteProduct(productId);
  }

  onAddProduct(productId: number) {
    const product = this.products.find((product) => product.id === productId);

    if (product) {
      this.orderService.addOrder(product);
    }
  }
}

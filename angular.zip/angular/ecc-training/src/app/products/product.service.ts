import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from './product.model';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor(private router: Router) {}

  private products: Product[] = [
    { id: 1, name: 'Smartphone', price: 29999, category: 'Electronics' },
    { id: 2, name: 'Laptop', price: 49999, category: 'Electronics' },
    { id: 3, name: 'Headphones', price: 1999, category: 'Accessories' },
    { id: 4, name: 'Running Shoes', price: 3999, category: 'Footwear' },
    { id: 5, name: 'Backpack', price: 1499, category: 'Accessories' },
  ];

  getAllProducts(): Product[] {
    return this.products;
  }

  deleteProduct(productId: number): void {
    const productIndex = this.products.findIndex(
      (product) => product.id === productId
    );

    this.products.splice(productIndex, 1);
  }

  addProduct(product: Product): void {
    this.products.push(product);
  }
}

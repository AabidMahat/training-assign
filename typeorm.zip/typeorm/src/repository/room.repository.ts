import { getRepository } from "typeorm";
import { RoomModel } from "../model/room.model";

class RoomRepo {
  async createRoom(room: Partial<RoomModel>) {
    const newRoom = getRepository(RoomModel).create(room);
    return await getRepository(RoomModel).save(newRoom);
  }

  async getRooms() {
    return await getRepository(RoomModel).find();
  }

  async getRoomById(roomId: number) {
    return await getRepository(RoomModel).findOne({
      where: {
        id: roomId,
      },
    });
  }

  async updateRoomById(roomId: number, data: Partial<RoomModel>) {
    return await getRepository(RoomModel).update(
      {
        id: roomId,
      },
      data
    );
  }

  async deleteRoomById(roomId: number) {
    return await getRepository(RoomModel).delete({
      id: roomId,
    });
  }
}

export default new RoomRepo();

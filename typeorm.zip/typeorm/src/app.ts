import express from "express";
import { RoomRouter } from "./routes/room.routing";

const app = express();

app.use(express.json());

app.use("/api/v1/rooms", RoomRouter);

export default app;

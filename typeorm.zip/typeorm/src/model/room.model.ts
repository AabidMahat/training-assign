import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";
import "reflect-metadata";

@Entity("room_tbl_data")
class RoomModel {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: "int",
    unique: true,
  })
  roomNumber: number;

  @Column({
    type: "varchar",
  })
  type: string;

  @Column({
    type: "numeric",
    default: 3000,
    nullable: false,
  })
  price: number;

  @Column({
    type: "bit",
    default: 1,
  })
  isAvaliable: boolean;
}

export { RoomModel };

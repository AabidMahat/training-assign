import { Request, Response } from "express";
import roomService from "../services/room.service";

class OrderController {
  async createNewRoom(req: Request, res: Response) {
    try {
      const newRoom = await roomService.createRoom(req.body);

      res.status(201).json({
        message: "Room created",
        data: newRoom,
      });
    } catch (err) {
      res.status(404).json({
        message: err,
      });
    }
  }
  async getAllRooms(req: Request, res: Response) {
    try {
      const rooms = await roomService.getAllRooms();

      res.status(200).json({
        message: "All Rooms",
        length: rooms.length,
        data: rooms,
      });
    } catch (err) {
      res.status(404).json({
        message: err,
      });
    }
  }
  async getRoomById(req: Request, res: Response) {
    try {
      const room = await roomService.getRoomById(+req.params.roomId);

      res.status(200).json({
        message: "Room by Id",
        data: room,
      });
    } catch (err) {
      res.status(404).json({
        message: err,
      });
    }
  }
  async updateRoomById(req: Request, res: Response) {
    try {
      const newRoom = await roomService.updateRoom(
        +req.params.roomId,
        req.body
      );

      res.status(201).json({
        message: "Room Updated",
        data: newRoom,
      });
    } catch (err) {
      res.status(404).json({
        message: err,
      });
    }
  }
  async deleteRoom(req: Request, res: Response) {
    try {
      await roomService.deleteRoomById(+req.params.roomId);

      res.status(200).json({
        message: "Room deleted",
      });
    } catch (err) {
      res.status(404).json({
        message: err,
      });
    }
  }
}

export default new OrderController();

import * as dotenv from "dotenv";

dotenv.config({
  path: "config.env",
});

import { createConnection } from "typeorm";
import { RoomModel } from "./model/room.model";

const AppDataSource = async () => {
  try {
    const connection = await createConnection({
      type: "mssql",
      host: process.env.DATABASE_HOST,
      port: 1982,
      database: "JIBE_Main_Training",
      entities: [RoomModel],
      synchronize: true,
      authentication: {
        type: "default",
        options: {
          userName: "j2",
          password: "123456",
        },
      },
      options: {
        encrypt: false,
        trustServerCertificate: true,
      },
    });
    console.log("Database connected successfully");
  } catch (err) {
    console.error("Database connection error:", err);
  }
};

export default AppDataSource;

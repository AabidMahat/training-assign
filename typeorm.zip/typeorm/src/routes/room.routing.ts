import express from "express";
import roomController from "../controllers/room.controller";

const router = express.Router();

router.route("/").post(roomController.createNewRoom);
router.route("/").get(roomController.getAllRooms);
router.route("/:roomId").get(roomController.getRoomById);
router.route("/:roomId").patch(roomController.updateRoomById);
router.route("/:roomId").delete(roomController.deleteRoom);

export { router as RoomRouter };

import app from "./app";
import AppDataSource from "./database.config";

AppDataSource();

app.listen(4000, () => {
  console.log("Listening to port 4000");
});

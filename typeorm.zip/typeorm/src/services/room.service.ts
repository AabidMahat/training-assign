import { RoomModel } from "../model/room.model";
import roomRepository from "../repository/room.repository";

class RoomService {
  async createRoom(room: Partial<RoomModel>) {
    return await roomRepository.createRoom(room);
  }
  async getAllRooms() {
    return await roomRepository.getRooms();
  }
  async getRoomById(roomId: number) {
    return await roomRepository.getRoomById(roomId);
  }
  async updateRoom(roomId: number, data: Partial<RoomModel>) {
    return await roomRepository.updateRoomById(roomId, data);
  }
  async deleteRoomById(roomId: number) {
    return await roomRepository.deleteRoomById(roomId);
  }
}

export default new RoomService();
